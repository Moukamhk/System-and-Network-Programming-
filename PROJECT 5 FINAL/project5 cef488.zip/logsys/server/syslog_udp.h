/*
 * syslog_udp.h — background UDP listener that accepts RFC 3164
 * syslog datagrams and folds them into the same log store as
 * everything else.
 */

#ifndef SYSLOG_UDP_H
#define SYSLOG_UDP_H

int syslog_udp_start(int port);
void syslog_udp_stop(void);

#endif /* SYSLOG_UDP_H */
