/*
 * syslog_udp.c — RFC 3164 UDP listener.
 *
 * Format:  <PRI>MMM DD HH:MM:SS HOSTNAME TAG: MESSAGE
 * Example: <34>Jul  6 09:32:05 myhost myapp: something happened
 *
 * NOTE: RFC 3164 pads single-digit days with a *space*, not a zero
 * ("Jul  6" not "Jul 06"), so the gap between the month and day can
 * be one OR two spaces depending on the day. A parser that just
 * counts "skip 3 space characters" breaks on single-digit days and
 * swallows part of the hostname field. We skip whitespace-delimited
 * tokens instead of counting raw space characters so both cases work.
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <time.h>
#include <pthread.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include "syslog_udp.h"
#include "log_store.h"
#include "../common/protocol.h"

static int udp_fd = -1;
static pthread_t udp_thread;
static volatile int udp_running = 0;

static char *skip_ws(char *p)    { while (*p == ' ') p++; return p; }
static char *skip_token(char *p) { while (*p && *p != ' ') p++; return p; }

/* severity 0-3 (Emerg/Alert/Crit/Err) -> CRITICAL
 * severity 4   (Warning)               -> WARN
 * severity 5-7 (Notice/Info/Debug)     -> INFO
 */
static int severity_to_level(int severity)
{
    if (severity <= 3) return LVL_CRITICAL;
    if (severity == 4) return LVL_WARN;
    return LVL_INFO;
}

/* Parses one datagram in place (buf is mutable, len bytes, NOT
 * null-terminated by the caller -- we do that here).
 * On success, writes client_id and message out and returns the
 * mapped level. Returns -1 on any parse failure. */
static int parse_rfc3164(char *buf, size_t len, char *client_id, size_t cid_sz,
                          char *message, size_t msg_sz)
{
    if (len == 0 || len >= MAX_LINE) return -1;
    buf[len] = '\0';

    if (buf[0] != '<') return -1;
    char *close = strchr(buf, '>');
    if (!close) return -1;
    *close = '\0';

    int pri = atoi(buf + 1);
    int severity = pri % 8;

    char *p = close + 1; /* start of "MMM DD HH:MM:SS ..." */

    /* skip month, day, time as three whitespace-delimited tokens */
    p = skip_ws(p);
    p = skip_token(p); /* month   */
    p = skip_ws(p);
    p = skip_token(p); /* day     */
    p = skip_ws(p);
    p = skip_token(p); /* HH:MM:SS */
    p = skip_ws(p);

    /* p now points at HOSTNAME */
    char *host_start = p;
    char *host_end = skip_token(p);
    if (host_end == host_start) return -1; /* no hostname present */

    size_t hlen = (size_t)(host_end - host_start);
    if (hlen >= cid_sz) hlen = cid_sz - 1;
    memcpy(client_id, host_start, hlen);
    client_id[hlen] = '\0';

    p = skip_ws(host_end);
    /* p now points at "TAG: MESSAGE" or just "MESSAGE" -- either way
     * we store the rest verbatim as the message body. */
    strncpy(message, p, msg_sz - 1);
    message[msg_sz - 1] = '\0';

    return severity_to_level(severity);
}

static void *udp_loop(void *arg)
{
    (void)arg;
    char buf[MAX_LINE];

    while (udp_running) {
        struct sockaddr_in from;
        socklen_t fromlen = sizeof(from);
        ssize_t n = recvfrom(udp_fd, buf, sizeof(buf) - 1, 0,
                              (struct sockaddr *)&from, &fromlen);
        if (n < 0) {
            if (!udp_running) break;
            continue;
        }

        char client_id[MAX_CLIENT_ID];
        char message[MAX_MESSAGE];
        int level = parse_rfc3164(buf, (size_t)n, client_id, sizeof(client_id),
                                   message, sizeof(message));
        if (level < 0) {
            fprintf(stderr, "[syslog_udp] dropped unparsable datagram\n");
            continue;
        }

        log_store_write(client_id, level, (long)time(NULL), message);
    }
    return NULL;
}

int syslog_udp_start(int port)
{
    udp_fd = socket(AF_INET, SOCK_DGRAM, 0);
    if (udp_fd < 0) { perror("[syslog_udp] socket"); return -1; }

    struct sockaddr_in addr = {0};
    addr.sin_family = AF_INET;
    addr.sin_addr.s_addr = INADDR_ANY;
    addr.sin_port = htons(port);

    if (bind(udp_fd, (struct sockaddr *)&addr, sizeof(addr)) < 0) {
        perror("[syslog_udp] bind");
        close(udp_fd);
        udp_fd = -1;
        return -1;
    }

    udp_running = 1;
    if (pthread_create(&udp_thread, NULL, udp_loop, NULL) != 0) {
        perror("[syslog_udp] pthread_create");
        udp_running = 0;
        close(udp_fd);
        return -1;
    }
    printf("[syslog_udp] listening on UDP port %d (RFC 3164)\n", port);
    return 0;
}

void syslog_udp_stop(void)
{
    if (!udp_running) return;
    udp_running = 0;
    shutdown(udp_fd, SHUT_RDWR);
    close(udp_fd);
    pthread_join(udp_thread, NULL);
}
