#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <sys/stat.h>
#include <dirent.h>
#include <pthread.h>
#include "log_store.h"
#include "../common/protocol.h"
#include "../common/json_util.h"

static char store_dir[MAX_PATH];
static pthread_mutex_t store_lock = PTHREAD_MUTEX_INITIALIZER;

int log_store_init(const char *dir)
{
    struct stat st;
    strncpy(store_dir, dir, sizeof(store_dir) - 1);

    if (stat(dir, &st) != 0) {
        if (mkdir(dir, 0755) != 0) {
            perror("[log_store] mkdir");
            return -1;
        }
        printf("[log_store] created directory: %s\n", dir);
    }
    return 0;
}

/* Build "logs/<client_id>_<YYYY-MM-DD>.log" for a given epoch time. */
static void build_path(char *out, size_t out_sz, const char *client_id, long ts)
{
    struct tm tm_buf;
    time_t t = (time_t)ts;
    localtime_r(&t, &tm_buf);

    char datestr[16];
    strftime(datestr, sizeof(datestr), "%Y-%m-%d", &tm_buf);

    snprintf(out, out_sz, "%s/%s_%s.log", store_dir, client_id, datestr);
}

int log_store_write(const char *client_id, int level, long ts, const char *message)
{
    char path[MAX_PATH];
    build_path(path, sizeof(path), client_id, ts);

    struct tm tm_buf;
    time_t t = (time_t)ts;
    localtime_r(&t, &tm_buf);
    char timestr[32];
    strftime(timestr, sizeof(timestr), "%Y-%m-%d %H:%M:%S", &tm_buf);

    pthread_mutex_lock(&store_lock);
    FILE *fp = fopen(path, "a");
    if (!fp) {
        perror("[log_store] fopen");
        pthread_mutex_unlock(&store_lock);
        return -1;
    }
    fprintf(fp, "[%s] [%-8s] [%s] %s (ts=%ld)\n",
            timestr, level_to_str(level), client_id, message, ts);
    fclose(fp);
    pthread_mutex_unlock(&store_lock);
    return 0;
}

/*
 * A log filename looks like "client_01_2026-07-06.log" or, for the
 * syslog listener, "some-hostname_2026-07-06.log". We only need the
 * client-id portion (everything before the trailing "_YYYY-MM-DD.log")
 * to test it against client_filter.
 */
static int filename_matches_client(const char *fname, const char *client_filter)
{
    if (!client_filter || client_filter[0] == '\0') return 1;

    size_t flen = strlen(fname);
    size_t clen = strlen(client_filter);
    if (clen >= flen) return 0;

    /* client filter must be a literal prefix of the filename, and be
     * immediately followed by '_' so "client_1" doesn't match
     * "client_10_...".
     */
    if (strncmp(fname, client_filter, clen) != 0) return 0;
    return fname[clen] == '_';
}

/* Parse one stored line back into level + epoch ts, then hand it to
 * emit() if it passes the filter. */
static void process_line(const char *line, int level_min,
                          long time_start, long time_end,
                          log_emit_fn emit, void *ctx, int *count)
{
    char level_buf[16] = {0};
    const char *lb = strchr(line, '[');
    if (!lb) return;
    lb = strchr(lb + 1, '['); /* second '[' opens the level field */
    if (!lb) return;
    lb++;
    int i = 0;
    while (*lb && *lb != ']' && *lb != ' ' && i + 1 < (int)sizeof(level_buf)) {
        level_buf[i++] = *lb++;
    }
    level_buf[i] = '\0';

    int level = level_to_int(level_buf);
    if (level < 0 || level < level_min) return;

    const char *tsmark = strstr(line, "ts=");
    if (!tsmark) return;
    long ts = atol(tsmark + 3);

    if (time_start != 0 && ts < time_start) return;
    if (time_end   != 0 && ts > time_end)   return;

    emit(line, ctx);
    (*count)++;
}

int log_store_query(const char *client_filter, int level_min,
                     long time_start, long time_end,
                     log_emit_fn emit, void *ctx)
{
    int count = 0;
    DIR *d = opendir(store_dir);
    if (!d) {
        perror("[log_store] opendir");
        return 0;
    }

    struct dirent *entry;
    pthread_mutex_lock(&store_lock);
    while ((entry = readdir(d)) != NULL) {
        if (entry->d_name[0] == '.') continue;
        /* skip already-rotated/compressed files */
        size_t nlen = strlen(entry->d_name);
        if (nlen < 4 || strcmp(entry->d_name + nlen - 4, ".log") != 0) continue;
        if (!filename_matches_client(entry->d_name, client_filter)) continue;

        char full[MAX_PATH + 300];
        snprintf(full, sizeof(full), "%s/%s", store_dir, entry->d_name);

        FILE *fp = fopen(full, "r");
        if (!fp) continue;

        char line[MAX_LINE];
        while (fgets(line, sizeof(line), fp)) {
            size_t len = strlen(line);
            if (len && line[len - 1] == '\n') line[len - 1] = '\0';
            process_line(line, level_min, time_start, time_end, emit, ctx, &count);
        }
        fclose(fp);
    }
    pthread_mutex_unlock(&store_lock);
    closedir(d);
    return count;
}
