/*
 * log_rotate.h — background thread that gzip-compresses log files
 * once they are no longer "today's" file.
 */

#ifndef LOG_ROTATE_H
#define LOG_ROTATE_H

/* Starts the background rotation thread. Checks every check_interval_sec
 * seconds and compresses any *.log file in dir that isn't today's date.
 * Returns 0 on success. */
int log_rotate_start(const char *dir, int check_interval_sec);

/* Signals the rotation thread to stop and joins it. */
void log_rotate_stop(void);

#endif /* LOG_ROTATE_H */
