#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <unistd.h>
#include <dirent.h>
#include <pthread.h>
#include "log_rotate.h"
#include "../common/protocol.h"

static char     rotate_dir[MAX_PATH];
static int      interval_sec = 60;
static pthread_t rotate_thread;
static volatile int rotate_running = 0;

/* Pull the "YYYY-MM-DD" chunk out of "client_01_2026-07-05.log". */
static int extract_date(const char *fname, char *out, size_t out_sz)
{
    size_t len = strlen(fname);
    if (len < 14) return -1; /* "_YYYY-MM-DD.log" is 15 chars minimum */

    const char *dot = strrchr(fname, '.');
    if (!dot || strcmp(dot, ".log") != 0) return -1;

    /* date is the 10 chars right before ".log" */
    const char *date_start = dot - 10;
    if (date_start < fname) return -1;
    if (date_start[-1] != '_') return -1; /* must be preceded by '_' */

    if (out_sz < 11) return -1;
    memcpy(out, date_start, 10);
    out[10] = '\0';
    return 0;
}

static void today_str(char *out, size_t out_sz)
{
    time_t now = time(NULL);
    struct tm tm_buf;
    localtime_r(&now, &tm_buf);
    strftime(out, out_sz, "%Y-%m-%d", &tm_buf);
}

/* Compress one file in place: "path" -> "path.gz", original removed
 * by gzip itself. Uses the system gzip binary rather than linking
 * zlib, since this project only needs "compress this file", not
 * streaming compression. */
static void compress_file(const char *path)
{
    char cmd[MAX_PATH + 16];
    snprintf(cmd, sizeof(cmd), "gzip -f '%s'", path);
    int rc = system(cmd);
    if (rc != 0) {
        fprintf(stderr, "[log_rotate] gzip failed for %s (rc=%d)\n", path, rc);
    } else {
        printf("[log_rotate] compressed %s\n", path);
    }
}

static void scan_and_rotate(void)
{
    char today[16];
    today_str(today, sizeof(today));

    DIR *d = opendir(rotate_dir);
    if (!d) return;

    struct dirent *entry;
    while ((entry = readdir(d)) != NULL) {
        if (entry->d_name[0] == '.') continue;

        char date[16];
        if (extract_date(entry->d_name, date, sizeof(date)) != 0) continue;
        if (strcmp(date, today) == 0) continue; /* still today, leave it */

        char full[MAX_PATH + 300];
        snprintf(full, sizeof(full), "%s/%s", rotate_dir, entry->d_name);
        compress_file(full);
    }
    closedir(d);
}

static void *rotate_loop(void *arg)
{
    (void)arg;
    while (rotate_running) {
        for (int i = 0; i < interval_sec && rotate_running; i++) {
            sleep(1);
        }
        if (rotate_running) scan_and_rotate();
    }
    return NULL;
}

int log_rotate_start(const char *dir, int check_interval_sec)
{
    strncpy(rotate_dir, dir, sizeof(rotate_dir) - 1);
    interval_sec = check_interval_sec;
    rotate_running = 1;

    if (pthread_create(&rotate_thread, NULL, rotate_loop, NULL) != 0) {
        perror("[log_rotate] pthread_create");
        rotate_running = 0;
        return -1;
    }
    return 0;
}

void log_rotate_stop(void)
{
    if (!rotate_running) return;
    rotate_running = 0;
    pthread_join(rotate_thread, NULL);
}
