/*
 * main.c — Centralized Logging Server (CEF488 Project 5)
 *
 * Architecture:
 *   - Listener A (LOG_PORT, 9000): accepts log-sending clients AND
 *     real-time monitor clients. One thread per connection.
 *   - Listener B (QUERY_PORT, 9001): accepts short-lived query
 *     connections. One thread per connection; the thread reads one
 *     query, writes the matching lines back, then closes.
 *   - A background thread (syslog_udp) listens for RFC 3164 UDP
 *     syslog packets on port 5140 and folds them into the same store.
 *   - A background thread (log_rotate) gzips yesterday-and-older log
 *     files every 60 seconds.
 *
 * Every log line that reaches ERROR or CRITICAL severity is fanned
 * out immediately to any connected monitor clients.
 *
 * Build: see Makefile (gcc ... -lpthread, gzip binary required at
 * runtime for rotation, no zlib dependency needed).
 */

#define _POSIX_C_SOURCE 200809L

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <time.h>
#include <signal.h>
#include <pthread.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netinet/tcp.h>
#include <arpa/inet.h>

#include "../common/protocol.h"
#include "../common/json_util.h"
#include "log_store.h"
#include "log_rotate.h"
#include "syslog_udp.h"

/* ── Monitor registry ── */
static int monitor_fds[MAX_CLIENTS];
static int monitor_count = 0;
static pthread_mutex_t monitor_lock = PTHREAD_MUTEX_INITIALIZER;

static volatile sig_atomic_t running = 1;
static int log_listen_fd = -1;
static int query_listen_fd = -1;

static void handle_signal(int sig)
{
    (void)sig;
    running = 0;
    if (log_listen_fd   >= 0) shutdown(log_listen_fd, SHUT_RDWR);
    if (query_listen_fd >= 0) shutdown(query_listen_fd, SHUT_RDWR);
}

static void add_monitor(int fd)
{
    pthread_mutex_lock(&monitor_lock);
    if (monitor_count < MAX_CLIENTS) {
        monitor_fds[monitor_count++] = fd;
    }
    pthread_mutex_unlock(&monitor_lock);
}

static void remove_monitor(int fd)
{
    pthread_mutex_lock(&monitor_lock);
    for (int i = 0; i < monitor_count; i++) {
        if (monitor_fds[i] == fd) {
            monitor_fds[i] = monitor_fds[monitor_count - 1];
            monitor_count--;
            break;
        }
    }
    pthread_mutex_unlock(&monitor_lock);
}

/* Send one already-formatted line to every connected monitor.
 * Dead sockets are just skipped here; they get cleaned up when their
 * own reader thread notices the disconnect. */
static void broadcast_to_monitors(const char *client_id, int level, const char *message)
{
    char line[MAX_LINE];
    time_t now = time(NULL);
    struct tm tm_buf;
    localtime_r(&now, &tm_buf);
    char timestr[32];
    strftime(timestr, sizeof(timestr), "%Y-%m-%d %H:%M:%S", &tm_buf);

    int n = snprintf(line, sizeof(line), "[%s] [%-8s] [%s] %s\n",
                      timestr, level_to_str(level), client_id, message);

    pthread_mutex_lock(&monitor_lock);
    for (int i = 0; i < monitor_count; i++) {
        /* best effort; ignore partial writes/errors, disconnect is
         * handled by that monitor's own connection thread */
        send(monitor_fds[i], line, (size_t)n, MSG_NOSIGNAL);
    }
    pthread_mutex_unlock(&monitor_lock);
}

/* Read one line (up to '\n') from fd into out. Returns bytes read
 * (0 on clean disconnect, -1 on error), and never includes the '\n'
 * itself in out. */
static ssize_t read_line(int fd, char *out, size_t out_sz)
{
    size_t i = 0;
    while (i + 1 < out_sz) {
        char c;
        ssize_t r = recv(fd, &c, 1, 0);
        if (r == 0) return (ssize_t)i;   /* disconnect */
        if (r < 0) return -1;             /* error      */
        if (c == '\n') break;
        out[i++] = c;
    }
    out[i] = '\0';
    return (ssize_t)i;
}

/* ── Handles one connection on LOG_PORT: either a log sender or a
 *    monitor. We don't know which until the first message arrives. */
static void *handle_log_connection(void *arg)
{
    int fd = (intptr_t)arg;
    int is_monitor = 0;
    char line[MAX_LINE];

    while (running) {
        ssize_t n = read_line(fd, line, sizeof(line));
        if (n <= 0) break;

        char type[16] = {0};
        if (json_get_str(line, "type", type, sizeof(type)) != 0) continue;

        if (strcmp(type, MSG_MONITOR) == 0) {
            is_monitor = 1;
            add_monitor(fd);
            const char *ack = "[server] monitor registered\n";
            send(fd, ack, strlen(ack), MSG_NOSIGNAL);
            continue;
        }

        if (strcmp(type, MSG_LOG) == 0) {
            char client_id[MAX_CLIENT_ID] = {0};
            char level_str[16] = {0};
            char message[MAX_MESSAGE] = {0};
            long ts = 0;

            json_get_str(line, "client_id", client_id, sizeof(client_id));
            json_get_str(line, "level", level_str, sizeof(level_str));
            json_get_str(line, "message", message, sizeof(message));
            if (json_get_long(line, "timestamp", &ts) != 0 || ts <= 0) {
                ts = (long)time(NULL);
            }

            int level = level_to_int(level_str);
            if (level < 0 || client_id[0] == '\0') {
                fprintf(stderr, "[server] malformed LOG message, dropped\n");
                continue;
            }

            log_store_write(client_id, level, ts, message);

            if (level >= LVL_ERROR) {
                broadcast_to_monitors(client_id, level, message);
            }
        }
    }

    if (is_monitor) remove_monitor(fd);
    close(fd);
    return NULL;
}

/* ── Handles one connection on QUERY_PORT: read a single QUERY
 *    message, stream matching lines back, close. */
struct query_ctx { int fd; };

static void emit_to_socket(const char *formatted_line, void *ctx)
{
    struct query_ctx *qc = (struct query_ctx *)ctx;
    char buf[MAX_LINE + 2];
    int n = snprintf(buf, sizeof(buf), "%s\n", formatted_line);
    send(qc->fd, buf, (size_t)n, MSG_NOSIGNAL);
}

static void *handle_query_connection(void *arg)
{
    int fd = (intptr_t)arg;
    char line[MAX_LINE];

    ssize_t n = read_line(fd, line, sizeof(line));
    if (n > 0) {
        char client_filter[MAX_CLIENT_ID] = {0};
        char level_min_str[16] = {0};
        long time_start = 0, time_end = 0;

        json_get_str(line, "client_id", client_filter, sizeof(client_filter));
        json_get_str(line, "level_min", level_min_str, sizeof(level_min_str));
        json_get_long(line, "time_start", &time_start);
        json_get_long(line, "time_end", &time_end);

        int level_min = level_to_int(level_min_str);
        if (level_min < 0) level_min = LVL_INFO;

        struct query_ctx ctx = { .fd = fd };
        int count = log_store_query(client_filter, level_min, time_start, time_end,
                                     emit_to_socket, &ctx);

        char footer[64];
        int fl = snprintf(footer, sizeof(footer), "--- END (%d matched) ---\n", count);
        send(fd, footer, (size_t)fl, MSG_NOSIGNAL);
    }

    close(fd);
    return NULL;
}

static int create_listener(int port)
{
    int fd = socket(AF_INET, SOCK_STREAM, 0);
    if (fd < 0) { perror("socket"); return -1; }

    int opt = 1;
    setsockopt(fd, SOL_SOCKET, SO_REUSEADDR, &opt, sizeof(opt));

    struct sockaddr_in addr = {0};
    addr.sin_family = AF_INET;
    addr.sin_addr.s_addr = INADDR_ANY;
    addr.sin_port = htons(port);

    if (bind(fd, (struct sockaddr *)&addr, sizeof(addr)) < 0) {
        perror("bind");
        close(fd);
        return -1;
    }
    if (listen(fd, 32) < 0) {
        perror("listen");
        close(fd);
        return -1;
    }
    return fd;
}

/* Each listener runs its own accept loop in its own thread, spawning
 * a detached worker thread per connection. */
struct listener_arg { int fd; void *(*handler)(void *); const char *name; };

static void *accept_loop(void *arg)
{
    struct listener_arg *la = (struct listener_arg *)arg;
    while (running) {
        struct sockaddr_in client_addr;
        socklen_t alen = sizeof(client_addr);
        int cfd = accept(la->fd, (struct sockaddr *)&client_addr, &alen);
        if (cfd < 0) {
            if (!running) break;
            continue;
        }

        pthread_t tid;
        if (pthread_create(&tid, NULL, la->handler, (void *)(intptr_t)cfd) != 0) {
            perror("pthread_create");
            close(cfd);
            continue;
        }
        pthread_detach(tid);
    }
    return NULL;
}

int main(void)
{
    signal(SIGINT, handle_signal);
    signal(SIGTERM, handle_signal);
    signal(SIGPIPE, SIG_IGN);

    if (log_store_init("logs") != 0) return 1;
    if (log_rotate_start("logs", 60) != 0) return 1;
    if (syslog_udp_start(SYSLOG_UDP_PORT) != 0) return 1;

    log_listen_fd   = create_listener(LOG_PORT);
    query_listen_fd = create_listener(QUERY_PORT);
    if (log_listen_fd < 0 || query_listen_fd < 0) return 1;

    printf("[server] log server listening on TCP port %d\n", LOG_PORT);
    printf("[server] query server listening on TCP port %d\n", QUERY_PORT);
    printf("[server] ready. press Ctrl+C to stop.\n");

    pthread_t log_accept_tid, query_accept_tid;
    struct listener_arg log_arg   = { log_listen_fd,   handle_log_connection,   "log"   };
    struct listener_arg query_arg = { query_listen_fd, handle_query_connection, "query" };

    pthread_create(&log_accept_tid,   NULL, accept_loop, &log_arg);
    pthread_create(&query_accept_tid, NULL, accept_loop, &query_arg);

    pthread_join(log_accept_tid, NULL);
    pthread_join(query_accept_tid, NULL);

    syslog_udp_stop();
    log_rotate_stop();
    close(log_listen_fd);
    close(query_listen_fd);
    printf("[server] shut down cleanly.\n");
    return 0;
}
