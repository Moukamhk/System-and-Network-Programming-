/*
 * log_store.h — writes log entries to per-client, per-day files and
 * answers filtered queries by re-reading those files.
 *
 * File layout:   logs/<client_id>_<YYYY-MM-DD>.log
 * Line format:   [YYYY-MM-DD HH:MM:SS] [LEVEL   ] [client_id] message (ts=EPOCH)
 *
 * We keep the human-readable timestamp for anyone tailing the file
 * by eye, and the raw epoch seconds at the end so queries can filter
 * by time range without re-parsing the date string.
 */

#ifndef LOG_STORE_H
#define LOG_STORE_H

/* Must be called once before any write/query. dir is created if missing. */
int log_store_init(const char *dir);

/* Append one entry to logs/<client_id>_<today>.log. Thread-safe. */
int log_store_write(const char *client_id, int level, long ts, const char *message);

/*
 * log_store_query()
 *
 * Scans every log file in the store directory whose client matches
 * client_filter (pass "" or NULL for "any client"), and for every
 * line whose level >= level_min and whose timestamp falls in
 * [time_start, time_end] (0 means "no bound"), calls emit(line, ctx).
 *
 * Returns the number of matching lines found.
 */
typedef void (*log_emit_fn)(const char *formatted_line, void *ctx);

int log_store_query(const char *client_filter, int level_min,
                     long time_start, long time_end,
                     log_emit_fn emit, void *ctx);

#endif /* LOG_STORE_H */
