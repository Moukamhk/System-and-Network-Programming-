/*
 * protocol.h
 *
 * Shared constants and wire-format definitions for the centralized
 * logging system. Both server and clients include this file so that
 * port numbers and field sizes never drift out of sync.
 *
 * Wire format: one JSON object per line, terminated by '\n'.
 * We do NOT use a general-purpose JSON library. Messages are small
 * and fixed-shape, so we build/parse them by hand in json_util.c.
 */

#ifndef PROTOCOL_H
#define PROTOCOL_H

#define LOG_PORT        9000   /* clients + monitors connect here    */
#define QUERY_PORT      9001   /* separate port, query-only traffic  */
#define SYSLOG_UDP_PORT 5140   /* RFC 3164 syslog, UDP                */

#define MAX_CLIENTS     64
#define MAX_LINE        1024
#define MAX_CLIENT_ID   64
#define MAX_MESSAGE     512
#define MAX_PATH        512

/* message "type" field values */
#define MSG_LOG      "LOG"
#define MSG_MONITOR  "MONITOR"
#define MSG_QUERY    "QUERY"

/* log levels, ordered low -> high severity for filtering */
#define LVL_INFO      0
#define LVL_WARN      1
#define LVL_ERROR     2
#define LVL_CRITICAL  3

#endif /* PROTOCOL_H */
