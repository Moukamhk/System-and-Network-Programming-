/*
 * json_util.h — tiny helpers for our flat, single-level JSON messages.
 *
 * This is NOT a general JSON parser. It only knows how to pull a
 * string or integer value out of a "key":value pair on a single line,
 * which is all our protocol ever sends. Keeping it this small means
 * no external dependency and no risk of a parser bug we don't
 * understand.
 */

#ifndef JSON_UTIL_H
#define JSON_UTIL_H

#include <stddef.h>

/* Extract a string value for "key":"value" into out (size out_sz).
 * Returns 0 on success, -1 if key not found. */
int json_get_str(const char *json, const char *key, char *out, size_t out_sz);

/* Extract a long integer value for "key":123 into out.
 * Returns 0 on success, -1 if key not found. */
int json_get_long(const char *json, const char *key, long *out);

/* Map a level string ("INFO","WARN","ERROR","CRITICAL") to LVL_* int.
 * Returns -1 if not recognized. */
int level_to_int(const char *level_str);

/* Map an LVL_* int back to its string name. */
const char *level_to_str(int level);

#endif /* JSON_UTIL_H */
