#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "json_util.h"
#include "protocol.h"

/*
 * json_get_str()
 *
 * Looks for  "key":"value"  inside json and copies value into out.
 * We search for the literal pattern "key" (with quotes) so we don't
 * accidentally match a substring inside another key name.
 */
int json_get_str(const char *json, const char *key, char *out, size_t out_sz)
{
    char pattern[64];
    snprintf(pattern, sizeof(pattern), "\"%s\"", key);

    const char *p = strstr(json, pattern);
    if (!p) return -1;

    p += strlen(pattern);
    /* skip ':' and whitespace */
    while (*p == ' ' || *p == ':') p++;
    if (*p != '"') return -1; /* value must be a quoted string */
    p++;

    size_t i = 0;
    while (*p && *p != '"' && i + 1 < out_sz) {
        out[i++] = *p++;
    }
    out[i] = '\0';
    return 0;
}

int json_get_long(const char *json, const char *key, long *out)
{
    char pattern[64];
    snprintf(pattern, sizeof(pattern), "\"%s\"", key);

    const char *p = strstr(json, pattern);
    if (!p) return -1;

    p += strlen(pattern);
    while (*p == ' ' || *p == ':') p++;
    if (*p == '"') return -1; /* value is a string, not a number */

    char *end;
    long val = strtol(p, &end, 10);
    if (end == p) return -1; /* nothing parsed */

    *out = val;
    return 0;
}

int level_to_int(const char *level_str)
{
    if (!level_str) return -1;
    if (strcmp(level_str, "INFO") == 0)     return LVL_INFO;
    if (strcmp(level_str, "WARN") == 0)     return LVL_WARN;
    if (strcmp(level_str, "ERROR") == 0)    return LVL_ERROR;
    if (strcmp(level_str, "CRITICAL") == 0) return LVL_CRITICAL;
    return -1;
}

const char *level_to_str(int level)
{
    switch (level) {
        case LVL_INFO:     return "INFO";
        case LVL_WARN:     return "WARN";
        case LVL_ERROR:    return "ERROR";
        case LVL_CRITICAL: return "CRITICAL";
        default:           return "UNKNOWN";
    }
}
