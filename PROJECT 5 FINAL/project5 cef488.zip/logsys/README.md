# Centralized Logging System — CEF488 Project 5

## Team
Fill in your name / matricule / group number here.

## What this is
A TCP server that multiple clients send structured log messages to,
plus tools to watch logs live and query them after the fact.

- Log messages carry a timestamp, a level (INFO / WARN / ERROR / CRITICAL),
  and a message string, sent as a single-line JSON object.
- The server writes each client's logs to its own file per day:
  `logs/<client_id>_<YYYY-MM-DD>.log`.
- A separate query connection lets you ask for logs filtered by
  client, minimum level, and/or a time range.
- Two extra features beyond the minimum requirement are included:
  1. **Real-time monitor** — a client that stays connected and prints
     ERROR/CRITICAL messages the instant the server receives them.
  2. **Log rotation + compression** — a background thread gzips any
     log file once it's no longer "today's" file.
  3. (bonus) **RFC 3164 UDP syslog** support on port 5140, so you can
     `logger` or `nc -u` a standard syslog line straight into the store.

## Ports
| Port | Protocol | Purpose                         |
|------|----------|----------------------------------|
| 9000 | TCP      | log ingestion + monitor clients  |
| 9001 | TCP      | query interface                  |
| 5140 | UDP      | RFC 3164 syslog                  |

## Build
```bash
make all
```
This builds `logserver`, `log_client`, `monitor`, and `query_client`.
No external libraries needed — rotation shells out to the system
`gzip` binary instead of linking zlib.

## Quick local test
```bash
# terminal 1
./logserver

# terminal 2
./monitor 127.0.0.1 mon01

# terminal 3
./log_client 127.0.0.1 web01 INFO     "Service started"
./log_client 127.0.0.1 web01 WARN     "Memory usage high"
./log_client 127.0.0.1 db01  ERROR    "Connection refused"
./log_client 127.0.0.1 web01 CRITICAL "Disk usage at 98%"

# terminal 4
./query_client 127.0.0.1
./query_client 127.0.0.1 --level CRITICAL
./query_client 127.0.0.1 --client web01 --level WARN
./query_client 127.0.0.1 --from 1751000000 --to 1751100000
```
Or just run `make test` for an automated version of the above.

Watch terminal 2 — only the ERROR and CRITICAL lines show up there,
in red, as soon as they're sent.

## Testing RFC 3164 syslog
```bash
echo "<34>Jul  6 09:05:00 host1 myapp: disk almost full" | nc -u 127.0.0.1 5140
```
Note the double space between "Jul" and "6" — that's not a typo, RFC 3164
pads single-digit days with a space instead of a zero. The parser skips
whitespace-delimited tokens rather than counting a fixed number of space
characters, specifically so this doesn't break the hostname parsing.

## Testing rotation
```bash
touch logs/testclient_$(date -d "yesterday" +%Y-%m-%d).log
echo "old line" >> logs/testclient_$(date -d "yesterday" +%Y-%m-%d).log
# wait up to 60 seconds
ls logs/   # testclient_*.log should now be testclient_*.log.gz
```

## 3-machine deployment
1. Same subnet, all machines can ping each other.
2. On the server machine, open the ports:
   ```bash
   sudo ufw allow 9000/tcp
   sudo ufw allow 9001/tcp
   sudo ufw allow 5140/udp
   ```
3. Copy the project (`scp -r` or zip + transfer) to the other machines
   and `make all` on each — or just copy the built binaries if all
   machines are the same architecture/OS.
4. `mkdir -p logs && ./logserver` on the server machine.
5. `./monitor <server_ip> <label>` and `./log_client <server_ip> ...`
   from the client machines.
6. `./query_client <server_ip> ...` from wherever.

If you don't have physical machines, three VirtualBox VMs on a
Bridged (or Host-Only) network adapter work the same way.

## Notes / known limits
- `json_util.c` is a minimal hand-rolled extractor for our specific
  flat message shape, not a general JSON parser — it will not handle
  nested objects, arrays, or escaped quotes inside strings.
- The server is thread-per-connection (one pthread per client), which
  is simple to reason about but wouldn't scale to thousands of
  concurrent connections; an epoll-based event loop would be the next
  step if that mattered.
- Log rotation checks every 60 seconds and compares each file's date
  suffix to today's date — it does not handle a server that's been
  down across a UTC/local boundary edge case perfectly, but this is a
  LAN course project, not a production log pipeline.
