/*
 * monitor.c — real-time monitor terminal.
 *
 * Connects to LOG_PORT, registers as a monitor, then prints every
 * ERROR/CRITICAL line the server fans out to it as it arrives.
 *
 * Usage: ./monitor <server_ip> [label]
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include "../common/protocol.h"

#define COLOR_RED   "\x1b[0;31m"
#define COLOR_RESET "\x1b[0m"

int main(int argc, char *argv[])
{
    if (argc < 2) {
        fprintf(stderr, "usage: %s <server_ip> [label]\n", argv[0]);
        return 1;
    }
    const char *server_ip = argv[1];
    const char *label = (argc > 2) ? argv[2] : "monitor";

    int fd = socket(AF_INET, SOCK_STREAM, 0);
    if (fd < 0) { perror("socket"); return 1; }

    struct sockaddr_in addr = {0};
    addr.sin_family = AF_INET;
    addr.sin_port = htons(LOG_PORT);
    if (inet_pton(AF_INET, server_ip, &addr.sin_addr) <= 0) {
        fprintf(stderr, "error: bad server IP '%s'\n", server_ip);
        return 1;
    }
    if (connect(fd, (struct sockaddr *)&addr, sizeof(addr)) < 0) {
        perror("connect");
        return 1;
    }

    char reg[MAX_LINE];
    int n = snprintf(reg, sizeof(reg), "{\"type\":\"%s\",\"client_id\":\"%s\"}\n",
                      MSG_MONITOR, label);
    send(fd, reg, (size_t)n, 0);

    printf("==================================================\n");
    printf("  Centralized Logging -- Real-Time Monitor\n");
    printf("  Connected to %s:%d as '%s'\n", server_ip, LOG_PORT, label);
    printf("  Showing ERROR and CRITICAL messages as they arrive\n");
    printf("  Ctrl+C to quit\n");
    printf("==================================================\n\n");
    fflush(stdout);

    char buf[MAX_LINE];
    ssize_t r;
    while ((r = recv(fd, buf, sizeof(buf) - 1, 0)) > 0) {
        buf[r] = '\0';
        if (strstr(buf, "CRITICAL") || strstr(buf, "ERROR")) {
            printf("%s%s%s", COLOR_RED, buf, COLOR_RESET);
        } else {
            printf("%s", buf);
        }
        fflush(stdout);
    }

    printf("[monitor] disconnected from server\n");
    close(fd);
    return 0;
}
