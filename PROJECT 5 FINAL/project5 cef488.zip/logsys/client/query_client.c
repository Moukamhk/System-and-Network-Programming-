/*
 * query_client.c — asks the server (on QUERY_PORT) for logs matching
 * an optional client / level / time-range filter.
 *
 * Usage:
 *   ./query_client <server_ip> [--client ID] [--level LVL]
 *                              [--from UNIX_TS] [--to UNIX_TS]
 *
 * --level LVL means "LVL or more severe" (INFO < WARN < ERROR < CRITICAL).
 * Omitted filters mean "no restriction".
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include "../common/protocol.h"
#include "../common/json_util.h"

int main(int argc, char *argv[])
{
    if (argc < 2) {
        fprintf(stderr, "usage: %s <server_ip> [--client ID] [--level LVL] "
                        "[--from TS] [--to TS]\n", argv[0]);
        return 1;
    }
    const char *server_ip = argv[1];

    char client_filter[MAX_CLIENT_ID] = "";
    char level_min[16] = "INFO";
    long time_start = 0, time_end = 0;

    for (int i = 2; i < argc; i++) {
        if (strcmp(argv[i], "--client") == 0 && i + 1 < argc) {
            strncpy(client_filter, argv[++i], sizeof(client_filter) - 1);
        } else if (strcmp(argv[i], "--level") == 0 && i + 1 < argc) {
            strncpy(level_min, argv[++i], sizeof(level_min) - 1);
        } else if (strcmp(argv[i], "--from") == 0 && i + 1 < argc) {
            time_start = atol(argv[++i]);
        } else if (strcmp(argv[i], "--to") == 0 && i + 1 < argc) {
            time_end = atol(argv[++i]);
        }
    }

    if (level_to_int(level_min) < 0) {
        fprintf(stderr, "error: unknown level '%s'\n", level_min);
        return 1;
    }

    int fd = socket(AF_INET, SOCK_STREAM, 0);
    if (fd < 0) { perror("socket"); return 1; }

    struct sockaddr_in addr = {0};
    addr.sin_family = AF_INET;
    addr.sin_port = htons(QUERY_PORT);
    if (inet_pton(AF_INET, server_ip, &addr.sin_addr) <= 0) {
        fprintf(stderr, "error: bad server IP '%s'\n", server_ip);
        return 1;
    }
    if (connect(fd, (struct sockaddr *)&addr, sizeof(addr)) < 0) {
        perror("connect");
        return 1;
    }

    char msg[MAX_LINE];
    int n = snprintf(msg, sizeof(msg),
        "{\"type\":\"%s\",\"client_id\":\"%s\",\"level_min\":\"%s\","
        "\"time_start\":%ld,\"time_end\":%ld}\n",
        MSG_QUERY, client_filter, level_min, time_start, time_end);
    send(fd, msg, (size_t)n, 0);

    printf("[query_client] filter: client='%s' level>=%s from=%ld to=%ld\n\n",
           client_filter[0] ? client_filter : "(any)", level_min, time_start, time_end);

    char buf[MAX_LINE];
    ssize_t r;
    while ((r = recv(fd, buf, sizeof(buf) - 1, 0)) > 0) {
        buf[r] = '\0';
        printf("%s", buf);
    }

    close(fd);
    return 0;
}
