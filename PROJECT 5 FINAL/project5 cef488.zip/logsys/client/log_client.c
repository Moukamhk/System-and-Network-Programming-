/*
 * log_client.c — sends one log message to the centralized server.
 *
 * Usage: ./log_client <server_ip> <client_id> <LEVEL> "<message>"
 * Example: ./log_client 127.0.0.1 web01 ERROR "Disk usage at 92%"
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <time.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include "../common/protocol.h"
#include "../common/json_util.h"

int main(int argc, char *argv[])
{
    if (argc < 5) {
        fprintf(stderr, "usage: %s <server_ip> <client_id> <LEVEL> <message>\n", argv[0]);
        fprintf(stderr, "  LEVEL is one of INFO, WARN, ERROR, CRITICAL\n");
        return 1;
    }

    const char *server_ip = argv[1];
    const char *client_id = argv[2];
    const char *level_str = argv[3];
    const char *message   = argv[4];

    if (level_to_int(level_str) < 0) {
        fprintf(stderr, "error: unknown level '%s'\n", level_str);
        return 1;
    }

    int fd = socket(AF_INET, SOCK_STREAM, 0);
    if (fd < 0) { perror("socket"); return 1; }

    struct sockaddr_in addr = {0};
    addr.sin_family = AF_INET;
    addr.sin_port = htons(LOG_PORT);
    if (inet_pton(AF_INET, server_ip, &addr.sin_addr) <= 0) {
        fprintf(stderr, "error: bad server IP '%s'\n", server_ip);
        return 1;
    }

    if (connect(fd, (struct sockaddr *)&addr, sizeof(addr)) < 0) {
        perror("connect");
        return 1;
    }

    char msg[MAX_LINE];
    long ts = (long)time(NULL);
    int n = snprintf(msg, sizeof(msg),
        "{\"type\":\"%s\",\"client_id\":\"%s\",\"level\":\"%s\",\"timestamp\":%ld,\"message\":\"%s\"}\n",
        MSG_LOG, client_id, level_str, ts, message);

    if (send(fd, msg, (size_t)n, 0) < 0) {
        perror("send");
        close(fd);
        return 1;
    }

    printf("[log_client] sent %s from '%s': %s\n", level_str, client_id, message);
    close(fd);
    return 0;
}
