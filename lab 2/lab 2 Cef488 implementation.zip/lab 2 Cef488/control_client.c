/*
 * control_client.c - Dynamic FIFO registration client
 *
 * Usage:
 *   ./control_client ADD /tmp/my_custom_fifo
 *
 * This sends a control command to the server's control FIFO so the
 * server adds a new FIFO to its epoll set at runtime, without restarting.
 *
 * Workflow:
 *   1. The user (or a process) creates a new FIFO with mkfifo().
 *   2. This tool sends "ADD /path\n" to /tmp/control.
 *   3. The server reads the command and opens /path for reading.
 *   4. The user can then use log_client to send messages to /path.
 *
 * Compile: gcc -Wall -Wextra -o control_client control_client.c
 */

#define _GNU_SOURCE
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <fcntl.h>
#include <errno.h>
#include <sys/stat.h>
#include <limits.h>

#ifndef PIPE_BUF
#define PIPE_BUF 4096
#endif

static const char *CONTROL_FIFO = "/tmp/control";

int main(int argc, char *argv[])
{
    if (argc < 3) {
        fprintf(stderr,
                "Usage: %s <COMMAND> <argument>\n"
                "  Commands:\n"
                "    ADD /path/to/fifo   -- register a new FIFO with the server\n"
                "\n"
                "  Example workflow:\n"
                "    mkfifo /tmp/my_app_log\n"
                "    %s ADD /tmp/my_app_log\n"
                "    ./log_client /tmp/my_app_log INFO \"hello from my app\"\n",
                argv[0], argv[0]);
        return EXIT_FAILURE;
    }

    const char *command   = argv[1];
    const char *argument  = argv[2];

    /* ── Validate command ──────────────────────────────────────── */
    if (strcmp(command, "ADD") != 0) {
        fprintf(stderr, "[control_client] Unknown command: %s\n", command);
        return EXIT_FAILURE;
    }

    /* ── For ADD: ensure the target FIFO exists ────────────────── */
    if (strcmp(command, "ADD") == 0) {
        struct stat st;
        if (stat(argument, &st) < 0) {
            /* Auto-create the FIFO if it doesn't exist */
            printf("[control_client] FIFO %s not found; creating it...\n", argument);
            if (mkfifo(argument, 0666) < 0) {
                perror("[control_client] mkfifo");
                return EXIT_FAILURE;
            }
            printf("[control_client] Created FIFO: %s\n", argument);
        } else if (!S_ISFIFO(st.st_mode)) {
            fprintf(stderr,
                    "[control_client] %s exists but is not a FIFO.\n", argument);
            return EXIT_FAILURE;
        }
    }

    /* ── Build the control message ─────────────────────────────── */
    char msg[PIPE_BUF];
    int  len = snprintf(msg, sizeof(msg), "%s %s\n", command, argument);
    if (len <= 0 || len >= PIPE_BUF) {
        fprintf(stderr, "[control_client] Control message too long.\n");
        return EXIT_FAILURE;
    }

    /* ── Open the control FIFO ─────────────────────────────────── */
    printf("[control_client] Connecting to control FIFO %s ...\n", CONTROL_FIFO);
    alarm(5);   /* don't hang if server is dead */
    int fd = open(CONTROL_FIFO, O_WRONLY);
    alarm(0);

    if (fd < 0) {
        perror("[control_client] open control FIFO");
        if (errno == ENXIO)
            fprintf(stderr,
                    "[control_client] No reader on control FIFO. Is the server running?\n");
        return EXIT_FAILURE;
    }

    /* ── Send the command (atomic write, len < PIPE_BUF) ──────── */
    ssize_t written = write(fd, msg, len);
    if (written < 0) {
        perror("[control_client] write");
        close(fd);
        return EXIT_FAILURE;
    }

    printf("[control_client] Sent: %s", msg);
    printf("[control_client] Server should now monitor: %s\n", argument);

    close(fd);
    return EXIT_SUCCESS;
}
