/*
 * log_client.c - Log message sender
 *
 * Usage:
 *   ./log_client <fifo_path> <LEVEL> <message>
 *
 * Example:
 *   ./log_client /tmp/fifo1 INFO  "Disk usage at 42%%"
 *   ./log_client /tmp/fifo2 CRITICAL "Out of memory!"
 *
 * The client sends messages in the format:  "LEVEL|message\n"
 * Each write() is guaranteed atomic because its length <= PIPE_BUF.
 *
 * Compile: gcc -Wall -Wextra -o log_client log_client.c
 */

#define _GNU_SOURCE
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <fcntl.h>
#include <errno.h>
#include <limits.h>      /* PIPE_BUF */

/* PIPE_BUF is the kernel guarantee for atomic writes.
 * On Linux this is 4096 bytes. Keep every message under this. */
#ifndef PIPE_BUF
#define PIPE_BUF 4096
#endif

int main(int argc, char *argv[])
{
    if (argc < 4) {
        fprintf(stderr,
                "Usage: %s <fifo_path> <LEVEL> <message>\n"
                "  LEVEL: INFO | WARN | ERROR | CRITICAL\n"
                "  Example: %s /tmp/fifo1 CRITICAL \"disk full\"\n",
                argv[0], argv[0]);
        return EXIT_FAILURE;
    }

    const char *fifo_path = argv[1];
    const char *level     = argv[2];
    const char *text      = argv[3];

    /* ── Build the message ─────────────────────────────────────────
     *
     * Format: "LEVEL|message text\n"
     * The newline is the message delimiter the server splits on.
     */
    char msg[PIPE_BUF];
    int  len = snprintf(msg, sizeof(msg), "%s|%s\n", level, text);

    if (len <= 0 || len >= PIPE_BUF) {
        fprintf(stderr,
                "[client] Message too long (%d bytes). Must be < %d (PIPE_BUF).\n"
                "         Split your message into smaller chunks.\n",
                len, PIPE_BUF);
        return EXIT_FAILURE;
    }

    /* ── Open the FIFO for writing ─────────────────────────────────
     *
     * open() on a FIFO in write-only mode blocks until a reader
     * exists. That is fine here: the server already has it open.
     * If the server is not running, we time out after 5 seconds.
     */
    printf("[client] Opening %s ...\n", fifo_path);

    /* Set a simple 5-second alarm so we don't hang forever */
    alarm(5);

    int fd = open(fifo_path, O_WRONLY);
    alarm(0);   /* cancel alarm */

    if (fd < 0) {
        perror("[client] open FIFO");
        if (errno == ENXIO)
            fprintf(stderr, "[client] No reader on the other end. Is the server running?\n");
        return EXIT_FAILURE;
    }

    /* ── Atomic write ──────────────────────────────────────────────
     *
     * Because len < PIPE_BUF, POSIX guarantees this write is atomic:
     * it will not be interleaved with concurrent writers on the same FIFO.
     * A partial write only occurs if len > PIPE_BUF, which we prevented
     * above.
     */
    printf("[client] Sending [%s]: %s\n", level, text);

    ssize_t written = write(fd, msg, len);
    if (written < 0) {
        perror("[client] write");
        close(fd);
        return EXIT_FAILURE;
    }

    if (written != len) {
        /* Should not happen for len < PIPE_BUF, but handle anyway */
        fprintf(stderr,
                "[client] Partial write: sent %zd of %d bytes\n",
                written, len);
        close(fd);
        return EXIT_FAILURE;
    }

    printf("[client] Message delivered (%zd bytes).\n", written);
    close(fd);
    return EXIT_SUCCESS;
}
