/*
 * log_server.c - Centralized Logging Server
 *
 * Architecture:
 *   - Creates 3 named FIFOs + 1 alert FIFO + 1 control FIFO
 *   - Uses epoll in EDGE-TRIGGERED mode to monitor all FIFOs
 *   - Messages format: "LEVEL|message\n"  (must be <= PIPE_BUF bytes)
 *   - Critical messages are forwarded to /tmp/alert_fifo
 *   - Control FIFO accepts "ADD /path/to/fifo" to register new FIFOs at runtime
 *   - SIGINT triggers clean shutdown (close fds, unlink FIFOs)
 *
 * Compile: gcc -Wall -Wextra -o log_server log_server.c
 */

#define _GNU_SOURCE
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <fcntl.h>
#include <errno.h>
#include <signal.h>
#include <time.h>
#include <sys/epoll.h>
#include <sys/stat.h>
#include <sys/types.h>

/* ─── Configuration ─────────────────────────────────────────────── */
#define MAX_EVENTS      64          /* max events returned per epoll_wait call  */
#define MAX_FIFOS       32          /* upper bound on dynamic FIFOs             */
#define BUF_SIZE        4096        /* read buffer; equals PIPE_BUF on Linux    */
#define MSG_MAX         4096        /* maximum single log message length        */

static const char *FIFO_PATHS[] = {
    "/tmp/fifo1",
    "/tmp/fifo2",
    "/tmp/fifo3",
    NULL
};
static const char *ALERT_FIFO  = "/tmp/alert_fifo";
static const char *CONTROL_FIFO = "/tmp/control";

/* ─── FIFO registry ──────────────────────────────────────────────── */
/*
 * We keep a table mapping file-descriptor → FIFO path so we can
 * log which pipe a message arrived on and clean up on removal.
 *
 * Each entry also holds a partial-message buffer to handle the case
 * where a single read() returns bytes that span a message boundary.
 */
typedef struct {
    int  fd;                    /* open file descriptor (-1 = slot free)  */
    char path[256];             /* filesystem path of this FIFO           */
    char partial[MSG_MAX];      /* bytes read but not yet a full message  */
    int  partial_len;           /* bytes valid in partial[]               */
    int  is_control;            /* 1 if this is the control FIFO          */
} FifoEntry;

static FifoEntry fifo_table[MAX_FIFOS];
static int       fifo_count  = 0;

/* ─── Globals ────────────────────────────────────────────────────── */
static int epfd       = -1;     /* epoll file descriptor                  */
static int alert_fd   = -1;     /* write-end of alert FIFO                */
static volatile sig_atomic_t running = 1; /* cleared by SIGINT handler    */

/* ─── Forward declarations ───────────────────────────────────────── */
static void  handle_sigint(int sig);
static int   create_and_open_fifo(const char *path, int flags);
static int   add_fifo_to_epoll(int fd, const char *path, int is_control);
static void  process_message(const char *path, const char *msg);
static void  handle_control_command(const char *cmd);
static void  remove_fifo(int fd);
static void  drain_fifo(FifoEntry *entry);
static void  cleanup(void);
static const char *timestamp(void);

/* ════════════════════════════════════════════════════════════════════
 * main()
 * ════════════════════════════════════════════════════════════════════ */
int main(void)
{
    /* Install SIGINT handler for graceful shutdown */
    struct sigaction sa = {0};
    sa.sa_handler = handle_sigint;
    sigaction(SIGINT, &sa, NULL);

    /* Initialise fifo_table to all-free */
    memset(fifo_table, 0, sizeof(fifo_table));
    for (int i = 0; i < MAX_FIFOS; i++)
        fifo_table[i].fd = -1;

    /* ── Create epoll instance ─────────────────────────────────── */
    epfd = epoll_create1(0);
    if (epfd < 0) { perror("epoll_create1"); exit(EXIT_FAILURE); }

    /* ── Create & open the three standard log FIFOs ───────────── */
    for (int i = 0; FIFO_PATHS[i]; i++) {
        int fd = create_and_open_fifo(FIFO_PATHS[i], O_RDONLY | O_NONBLOCK);
        if (fd < 0) {
            fprintf(stderr, "[server] WARNING: could not open %s\n", FIFO_PATHS[i]);
            continue;
        }
        if (add_fifo_to_epoll(fd, FIFO_PATHS[i], 0) < 0) {
            close(fd);
        }
    }

    /* ── Create & open the control FIFO ───────────────────────── */
    {
        int fd = create_and_open_fifo(CONTROL_FIFO, O_RDONLY | O_NONBLOCK);
        if (fd >= 0) {
            add_fifo_to_epoll(fd, CONTROL_FIFO, 1);
        } else {
            fprintf(stderr, "[server] WARNING: could not open control FIFO\n");
        }
    }

    /* ── Open alert FIFO for writing (non-blocking) ────────────
     *
     * O_WRONLY | O_NONBLOCK on a FIFO without a reader returns ENXIO.
     * We use O_RDWR so we are simultaneously reader+writer; this keeps
     * the FIFO open even when no external reader is attached and avoids
     * SIGPIPE if no cat process is listening.
     */
    {
        /* Ensure alert FIFO exists */
        if (mkfifo(ALERT_FIFO, 0666) < 0 && errno != EEXIST) {
            perror("mkfifo alert_fifo");
        }
        alert_fd = open(ALERT_FIFO, O_RDWR | O_NONBLOCK);
        if (alert_fd < 0) {
            perror("open alert_fifo");
            /* non-fatal: server continues without alerting */
        }
    }

    printf("[server] Started. Monitoring %d FIFOs. Press Ctrl+C to stop.\n", fifo_count);
    fflush(stdout);

    /* ════════════════════════════════════════════════════════════
     * Main event loop
     * ════════════════════════════════════════════════════════════ */
    struct epoll_event events[MAX_EVENTS];

    while (running) {
        /*
         * epoll_wait blocks until:
         *   (a) at least one fd becomes readable, OR
         *   (b) the 1-second timeout expires, OR
         *   (c) it is interrupted by a signal (EINTR).
         */
        int n = epoll_wait(epfd, events, MAX_EVENTS, 1000 /* ms */);

        if (n < 0) {
            if (errno == EINTR) continue;   /* woken by SIGINT – loop & exit */
            perror("epoll_wait");
            break;
        }

        for (int i = 0; i < n; i++) {
            int fd = events[i].data.fd;

            /* Find the matching FifoEntry */
            FifoEntry *entry = NULL;
            for (int j = 0; j < MAX_FIFOS; j++) {
                if (fifo_table[j].fd == fd) { entry = &fifo_table[j]; break; }
            }
            if (!entry) continue;

            /*
             * EDGE-TRIGGERED: we MUST read until EAGAIN.
             * drain_fifo() does that and calls process_message() for
             * each complete newline-terminated record it finds.
             */
            if (events[i].events & EPOLLIN) {
                drain_fifo(entry);
            }

            /*
             * EPOLLHUP: the last writer closed its end.
             * read() will return 0 (EOF). We remove the FIFO from epoll
             * and free its slot so we don't accumulate dead descriptors.
             *
             * NOTE: for the static FIFOs (/tmp/fifo1-3) we leave them in
             * the filesystem so a new client can open them later.
             */
            if (events[i].events & (EPOLLHUP | EPOLLERR)) {
    /* Find which slot this fd belongs to */
    int slot = -1;
    for (int j = 0; j < MAX_FIFOS; j++) {
        if (fifo_table[j].fd == fd) {
            slot = j;
            break;
        }
    }
    if (slot < 0) continue;

    char saved_path[256];
    strncpy(saved_path, fifo_table[slot].path, sizeof(saved_path) - 1);
    saved_path[sizeof(saved_path) - 1] = '\0';

    epoll_ctl(epfd, EPOLL_CTL_DEL, fd, NULL);
    close(fd);
    fifo_table[slot].fd = -1;

    int new_fd = open(saved_path, O_RDONLY | O_NONBLOCK);
    if (new_fd < 0) {
        perror("reopen fifo");
        continue;
    }

    fifo_table[slot].fd = new_fd;

    struct epoll_event ev;
    ev.events  = EPOLLIN | EPOLLET;
    ev.data.fd = new_fd;
    epoll_ctl(epfd, EPOLL_CTL_ADD, new_fd, &ev);
    fprintf(stderr, "[server] Reopened %s\n", saved_path);
}
        }
    }

    cleanup();
    return 0;
}

/* ════════════════════════════════════════════════════════════════════
 * Signal handler
 * ════════════════════════════════════════════════════════════════════ */
static void handle_sigint(int sig)
{
    (void)sig;
    running = 0;   /* signal-safe: just flip the flag */
}

/* ════════════════════════════════════════════════════════════════════
 * create_and_open_fifo()
 *   mkfifo() if needed, then open() with given flags.
 *   Returns fd on success, -1 on error.
 * ════════════════════════════════════════════════════════════════════ */
static int create_and_open_fifo(const char *path, int flags)
{
    /* mkfifo returns EEXIST if it already exists – that's fine */
    if (mkfifo(path, 0666) < 0 && errno != EEXIST) {
        perror("mkfifo");
        return -1;
    }

    int fd = open(path, flags);
    if (fd < 0) {
        /* ENXIO = O_NONBLOCK | O_WRONLY with no reader yet */
        if (errno != ENXIO)
            perror("open fifo");
        return -1;
    }
    return fd;
}

/* ════════════════════════════════════════════════════════════════════
 * add_fifo_to_epoll()
 *   Registers fd with epoll (EPOLLIN | EPOLLET) and records metadata.
 *   Returns 0 on success, -1 on error.
 * ════════════════════════════════════════════════════════════════════ */
static int add_fifo_to_epoll(int fd, const char *path, int is_control)
{
    if (fifo_count >= MAX_FIFOS) {
        fprintf(stderr, "[server] FIFO table full – cannot add %s\n", path);
        return -1;
    }

    struct epoll_event ev = {0};
    ev.events  = EPOLLIN | EPOLLET;  /* edge-triggered read notification */
    ev.data.fd = fd;

    if (epoll_ctl(epfd, EPOLL_CTL_ADD, fd, &ev) < 0) {
        perror("epoll_ctl ADD");
        return -1;
    }

    /* Find a free slot in the table */
    for (int i = 0; i < MAX_FIFOS; i++) {
        if (fifo_table[i].fd == -1) {
            fifo_table[i].fd          = fd;
            fifo_table[i].partial_len = 0;
            fifo_table[i].is_control  = is_control;
            strncpy(fifo_table[i].path, path, sizeof(fifo_table[i].path) - 1);
            fifo_count++;
            printf("[server] %s Registered FIFO: %s (fd=%d)\n",
                   timestamp(), path, fd);
            return 0;
        }
    }
    /* Should never reach here if fifo_count < MAX_FIFOS */
    return -1;
}

/* ════════════════════════════════════════════════════════════════════
 * drain_fifo()
 *   Edge-triggered loop: read() until EAGAIN.
 *   Accumulates bytes in entry->partial[], splitting on '\n' to
 *   deliver complete messages to process_message().
 * ════════════════════════════════════════════════════════════════════ */
static void drain_fifo(FifoEntry *entry)
{
    char buf[BUF_SIZE];

    while (1) {
        ssize_t n = read(entry->fd, buf, sizeof(buf));

        if (n < 0) {
            if (errno == EAGAIN || errno == EWOULDBLOCK)
                break;          /* no more data right now – done for this event */
            perror("read fifo");
            break;
        }

        if (n == 0) {
            /* EOF: writer closed its end. Caller checks EPOLLHUP. */
            break;
        }

        /* Append freshly-read bytes to the partial buffer */
        int space = MSG_MAX - entry->partial_len - 1;
        if (n > space) n = space;   /* truncate if message is absurdly large */
        memcpy(entry->partial + entry->partial_len, buf, n);
        entry->partial_len += n;
        entry->partial[entry->partial_len] = '\0';

        /* Split on newlines to extract complete messages */
        char *start = entry->partial;
        char *nl;
        while ((nl = memchr(start, '\n', entry->partial + entry->partial_len - start)) != NULL) {
            *nl = '\0';           /* null-terminate the message in-place  */

            if (entry->is_control)
                handle_control_command(start);
            else
                process_message(entry->path, start);

            start = nl + 1;       /* advance past the newline             */
        }

        /* Shift any remaining incomplete message to the front */
        int remaining = (entry->partial + entry->partial_len) - start;
        if (remaining > 0 && start != entry->partial)
            memmove(entry->partial, start, remaining);
        entry->partial_len = remaining;
        entry->partial[remaining] = '\0';
    }
}

/* ════════════════════════════════════════════════════════════════════
 * process_message()
 *   Parses "LEVEL|text" and prints with a timestamp.
 *   Forwards CRITICAL messages to the alert FIFO.
 * ════════════════════════════════════════════════════════════════════ */
static void process_message(const char *path, const char *msg)
{
    if (!msg || msg[0] == '\0') return;

    /* Parse level and text (format: LEVEL|message text) */
    char level[32] = "UNKNOWN";
    char text[MSG_MAX] = "";

    const char *pipe_pos = strchr(msg, '|');
    if (pipe_pos) {
        int llen = (int)(pipe_pos - msg);
        if (llen >= (int)sizeof(level)) llen = (int)sizeof(level) - 1;
        strncpy(level, msg, llen);
        level[llen] = '\0';
        strncpy(text, pipe_pos + 1, sizeof(text) - 1);
    } else {
        strncpy(text, msg, sizeof(text) - 1);
    }

    printf("[%s] [%-8s] [%s] %s\n", timestamp(), level, path, text);
    fflush(stdout);

    /* Forward CRITICAL messages to the alert FIFO */
    if (strcmp(level, "CRITICAL") == 0 && alert_fd >= 0) {
        char alert_msg[MSG_MAX + 64];
        int  len = snprintf(alert_msg, sizeof(alert_msg),
                            "ALERT [%s] from %s: %s\n",
                            timestamp(), path, text);
        /*
         * write() of <= PIPE_BUF bytes is atomic; we keep alert_msg
         * within that limit so it is never interleaved with other writers.
         */
        if (len > 0) {
            ssize_t w = write(alert_fd, alert_msg, len);
            if (w < 0 && errno != EAGAIN)
                perror("write alert_fifo");
        }
    }
}

/* ════════════════════════════════════════════════════════════════════
 * handle_control_command()
 *   Parses commands from /tmp/control.
 *   Supported: "ADD /path/to/fifo"
 * ════════════════════════════════════════════════════════════════════ */
static void handle_control_command(const char *cmd)
{
    if (!cmd || cmd[0] == '\0') return;

    printf("[server] %s Control command: '%s'\n", timestamp(), cmd);

    if (strncmp(cmd, "ADD ", 4) == 0) {
        const char *path = cmd + 4;
        /* Trim leading whitespace */
        while (*path == ' ') path++;
        if (*path == '\0') {
            fprintf(stderr, "[server] ADD: missing path\n");
            return;
        }

        /* Prevent duplicate registration */
        for (int i = 0; i < MAX_FIFOS; i++) {
            if (fifo_table[i].fd != -1 &&
                strcmp(fifo_table[i].path, path) == 0) {
                printf("[server] %s FIFO already registered: %s\n",
                       timestamp(), path);
                return;
            }
        }

        int fd = create_and_open_fifo(path, O_RDONLY | O_NONBLOCK);
        if (fd < 0) {
            fprintf(stderr, "[server] ADD failed for %s\n", path);
            return;
        }
        if (add_fifo_to_epoll(fd, path, 0) < 0) {
            close(fd);
        }
    } else {
        fprintf(stderr, "[server] Unknown control command: %s\n", cmd);
    }
}

/* ════════════════════════════════════════════════════════════════════
 * cleanup()
 *   Close all open fds, unlink all FIFOs.
 * ════════════════════════════════════════════════════════════════════ */
static void cleanup(void)
{
    printf("\n[server] Shutting down...\n");

    for (int i = 0; i < MAX_FIFOS; i++) {
        if (fifo_table[i].fd != -1) {
            close(fifo_table[i].fd);
            unlink(fifo_table[i].path);
            printf("[server] Removed FIFO: %s\n", fifo_table[i].path);
        }
    }

    if (alert_fd >= 0) {
        close(alert_fd);
        unlink(ALERT_FIFO);
        printf("[server] Removed alert FIFO: %s\n", ALERT_FIFO);
    }

    if (epfd >= 0) close(epfd);

    printf("[server] Done.\n");
}

/* ════════════════════════════════════════════════════════════════════
 * timestamp()
 *   Returns a static string "HH:MM:SS" for the current local time.
 *   NOT thread-safe, but we are single-threaded.
 * ════════════════════════════════════════════════════════════════════ */
static const char *timestamp(void)
{
    static char buf[16];
    time_t t = time(NULL);
    struct tm *tm = localtime(&t);
    strftime(buf, sizeof(buf), "%H:%M:%S", tm);
    return buf;
}
