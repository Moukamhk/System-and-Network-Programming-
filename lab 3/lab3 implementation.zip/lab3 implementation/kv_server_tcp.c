#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <fcntl.h>
#include <errno.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netdb.h>
#include <sys/epoll.h>
#include <signal.h>
#include <netinet/tcp.h>
#include <netinet/in.h>
#include <arpa/inet.h>

#include "kv_protocol.h"
#include "kv_store.h"

#define BUF_SIZE 8192
#define MAX_EVENTS 64

static volatile int keep_running = 1;

struct client_context {
    int fd;
    char buf[BUF_SIZE];
    size_t bytes_in_buf;
    char ip_str[INET6_ADDRSTRLEN];
    int port;
};

static void handle_signal(int sig) {
    (void)sig;
    printf("\n[SERVER] Shutdown signal received. Stopping event loop...\n");
    keep_running = 0;
}

static int set_nonblocking(int fd) {
    int flags = fcntl(fd, F_GETFL, 0);
    if (flags == -1) return -1;
    return fcntl(fd, F_SETFL, flags | O_NONBLOCK);
}

static void apply_socket_options(int fd, int tcp_nodelay, int keepalive, int rcvbuf, int sndbuf) {
    int val = 1;
    if (tcp_nodelay) {
        setsockopt(fd, IPPROTO_TCP, TCP_NODELAY, &val, sizeof(val));
    }
    if (keepalive) {
        setsockopt(fd, SOL_SOCKET, SO_KEEPALIVE, &val, sizeof(val));
    }
    if (rcvbuf > 0) {
        setsockopt(fd, SOL_SOCKET, SO_RCVBUF, &rcvbuf, sizeof(rcvbuf));
    }
    if (sndbuf > 0) {
        setsockopt(fd, SOL_SOCKET, SO_SNDBUF, &sndbuf, sizeof(sndbuf));
    }
}

static void process_client_buffer(struct client_context *ctx) {
    while (ctx->bytes_in_buf >= sizeof(struct kv_request)) {
        struct kv_request req;
        memcpy(&req, ctx->buf, sizeof(struct kv_request));

        uint32_t len = ntohl(req.length);
        uint32_t op = ntohl(req.opcode);

        if (ctx->bytes_in_buf < len) return;

        char key[256] = {0};
        char val_buf[4096] = {0};
        size_t header_offset = sizeof(struct kv_request);

        if (len > header_offset) {
            size_t payload_len = len - header_offset;
            if (op == OP_SET) {
                size_t key_bytes = (payload_len < sizeof(key) - 1) ? payload_len : sizeof(key) - 1;
                memcpy(key, ctx->buf + header_offset, key_bytes);
                key[key_bytes] = '\0';
                
                size_t key_len = strlen(key) + 1;
                if (key_len < payload_len) {
                    size_t v_len = payload_len - key_len;
                    if (v_len > sizeof(val_buf) - 1) v_len = sizeof(val_buf) - 1;
                    memcpy(val_buf, ctx->buf + header_offset + key_len, v_len);
                }
            } else {
                size_t key_bytes = (payload_len < sizeof(key) - 1) ? payload_len : sizeof(key) - 1;
                memcpy(key, ctx->buf + header_offset, key_bytes);
                key[key_bytes] = '\0';
            }
        }

        char resp_buf[BUF_SIZE];
        memset(resp_buf, 0, sizeof(resp_buf));
        struct kv_response *res = (struct kv_response *)resp_buf;
        size_t resp_payload_len = 0;

        /* LOG REQUEST TYPE AND CLIENT IN SERVER TERMINAL */
        if (op == OP_SET) {
            printf("[REQUEST] SET received from %s:%d | Key: '%s' | Value: '%s'\n", ctx->ip_str, ctx->port, key, val_buf);
            store_set(key, val_buf);
            res->status = htonl(STATUS_SUCCESS);
        } else if (op == OP_GET) {
            printf("[REQUEST] GET received from %s:%d | Key: '%s'\n", ctx->ip_str, ctx->port, key);
            char *found = store_get(key);
            if (found) {
                res->status = htonl(STATUS_SUCCESS);
                resp_payload_len = strlen(found) + 1;
                memcpy(resp_buf + sizeof(struct kv_response), found, resp_payload_len);
            } else {
                res->status = htonl(STATUS_NOT_FOUND);
            }
        } else if (op == OP_DEL) {
            printf("[REQUEST] DEL received from %s:%d | Key: '%s'\n", ctx->ip_str, ctx->port, key);
            if (store_del(key) == 0) {
                res->status = htonl(STATUS_SUCCESS);
            } else {
                res->status = htonl(STATUS_NOT_FOUND);
            }
        } else {
            printf("[REQUEST] Unknown Opcode received from %s:%d\n", ctx->ip_str, ctx->port);
            res->status = htonl(STATUS_ERROR);
        }

        res->length = htonl(sizeof(struct kv_response) + resp_payload_len);
        send(ctx->fd, resp_buf, sizeof(struct kv_response) + resp_payload_len, 0);

        memmove(ctx->buf, ctx->buf + len, ctx->bytes_in_buf - len);
        ctx->bytes_in_buf -= len;
    }
}

int main(int argc, char *argv[]) {
    char *port = "5001";
    int tcp_nodelay = 0, keepalive = 0, rcvbuf = 0, sndbuf = 0;

    for (int i = 1; i < argc; i++) {
        if (strcmp(argv[i], "--tcp-nodelay") == 0) {
            tcp_nodelay = 1;
        } else if (strcmp(argv[i], "--keepalive") == 0) {
            keepalive = 1;
        } else if (strcmp(argv[i], "--rcvbuf") == 0 && i + 1 < argc) {
            rcvbuf = atoi(argv[++i]);
        } else if (strcmp(argv[i], "--sndbuf") == 0 && i + 1 < argc) {
            sndbuf = atoi(argv[++i]);
        } else {
            port = argv[i];
        }
    }

    struct sigaction sa;
    memset(&sa, 0, sizeof(sa));
    sa.sa_handler = handle_signal;
    sigaction(SIGINT, &sa, NULL);

    store_init();

    struct addrinfo hints, *result, *rp;
    memset(&hints, 0, sizeof(hints));
    hints.ai_family = AF_INET6; 
    hints.ai_socktype = SOCK_STREAM;
    hints.ai_flags = AI_PASSIVE;

    if (getaddrinfo(NULL, port, &hints, &result) != 0) {
        perror("getaddrinfo");
        return 1;
    }

    int listen_fd = -1;
    for (rp = result; rp != NULL; rp = rp->ai_next) {
        listen_fd = socket(rp->ai_family, rp->ai_socktype, rp->ai_protocol);
        if (listen_fd == -1) continue;

        int opt = 1;
        setsockopt(listen_fd, SOL_SOCKET, SO_REUSEADDR, &opt, sizeof(opt));

        int v6only = 0; 
        setsockopt(listen_fd, IPPROTO_IPV6, IPV6_V6ONLY, &v6only, sizeof(v6only));

        if (bind(listen_fd, rp->ai_addr, rp->ai_addrlen) == 0) break;
        close(listen_fd);
    }

    freeaddrinfo(result);

    if (!rp) {
        fprintf(stderr, "Could not bind server socket\n");
        return 1;
    }

    if (listen(listen_fd, 128) == -1) {
        perror("listen");
        return 1;
    }

    set_nonblocking(listen_fd);

    int epoll_fd = epoll_create1(0);
    struct epoll_event ev, events[MAX_EVENTS];
    ev.events = EPOLLIN;
    ev.data.fd = listen_fd;
    epoll_ctl(epoll_fd, EPOLL_CTL_ADD, listen_fd, &ev);

    printf("[STARTUP] TCP Server active on port %s (Dual Stack Mapped)...\n", port);

    while (keep_running) {
        int nfds = epoll_wait(epoll_fd, events, MAX_EVENTS, 200);
        for (int i = 0; i < nfds; i++) {
            if (events[i].data.fd == listen_fd) {
                struct sockaddr_storage cli_addr;
                socklen_t cli_len = sizeof(cli_addr);
                int client_fd = accept(listen_fd, (struct sockaddr *)&cli_addr, &cli_len);
                if (client_fd == -1) continue;

                set_nonblocking(client_fd);
                apply_socket_options(client_fd, tcp_nodelay, keepalive, rcvbuf, sndbuf);

                struct client_context *ctx = calloc(1, sizeof(struct client_context));
                ctx->fd = client_fd;

                /* EXTRACT AND LOG CLIENT CONNECTION INFO */
                if (cli_addr.ss_family == AF_INET) {
                    struct sockaddr_in *s = (struct sockaddr_in *)&cli_addr;
                    inet_ntop(AF_INET, &s->sin_addr, ctx->ip_str, sizeof(ctx->ip_str));
                    ctx->port = ntohs(s->sin_port);
                } else {
                    struct sockaddr_in6 *s = (struct sockaddr_in6 *)&cli_addr;
                    inet_ntop(AF_INET6, &s->sin6_addr, ctx->ip_str, sizeof(ctx->ip_str));
                    ctx->port = ntohs(s->sin6_port);
                }
                printf("[CONNECT] New client connection accepted from %s:%d\n", ctx->ip_str, ctx->port);

                struct epoll_event civ;
                civ.events = EPOLLIN | EPOLLET; 
                civ.data.ptr = ctx;
                epoll_ctl(epoll_fd, EPOLL_CTL_ADD, client_fd, &civ);
            } else {
                struct client_context *ctx = (struct client_context *)events[i].data.ptr;
                int disconnect = 0;
                while (1) {
                    ssize_t n = read(ctx->fd, ctx->buf + ctx->bytes_in_buf, BUF_SIZE - ctx->bytes_in_buf);
                    if (n > 0) {
                        ctx->bytes_in_buf += n;
                        process_client_buffer(ctx);
                    } else if (n < 0) {
                        if (errno == EAGAIN || errno == EWOULDBLOCK) {
                            break; 
                        }
                        disconnect = 1;
                        break;
                    } else {
                        disconnect = 1;
                        break;
                    }
                }

                if (disconnect) {
                    /* LOG DISCONNECTION EVENT */
                    printf("[DISCONNECT] Client %s:%d closed connection\n", ctx->ip_str, ctx->port);
                    epoll_ctl(epoll_fd, EPOLL_CTL_DEL, ctx->fd, NULL);
                    close(ctx->fd);
                    free(ctx);
                }
            }
        }
    }

    /* LOG CLEAN SHUTDOWN */
    printf("[SHUTDOWN] Releasing socket descriptors and destroying hash indexes...\n");
    close(listen_fd);
    close(epoll_fd);
    store_destroy();
    printf("[SHUTDOWN] Server cleanly terminated.\n");
    return 0;
}