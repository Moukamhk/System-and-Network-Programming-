#ifndef KV_PROTOCOL_H
#define KV_PROTOCOL_H

#include <stdint.h>

/* Opcodes */
#define OP_SET 1
#define OP_GET 2
#define OP_DEL 3

/* Status Codes */
#define STATUS_SUCCESS   0
#define STATUS_NOT_FOUND 1
#define STATUS_ERROR     2

/* Fixed Request Header Structure */
struct kv_request {
    uint32_t length;  /* Total frame length: sizeof(struct kv_request) + key_len + val_len */
    uint32_t opcode;  /* OP_SET, OP_GET, OP_DEL */
} __attribute__((packed));

/* Fixed Response Header Structure */
struct kv_response {
    uint32_t length;  /* Total frame length: sizeof(struct kv_response) + data_len */
    uint32_t status;  /* STATUS_SUCCESS, STATUS_NOT_FOUND, STATUS_ERROR */
} __attribute__((packed));

#endif /* KV_PROTOCOL_H */