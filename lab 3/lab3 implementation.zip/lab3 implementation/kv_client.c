#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netdb.h>
#include <sys/time.h>
#include <netinet/in.h>

#include "kv_protocol.h"

#define BUF_SIZE 8192

int main(int argc, char *argv[]) {
    char *host = "localhost";
    char *port = "5001";
    int use_udp = 0;
    char *op_str = NULL;
    char *key = NULL;
    char *val = NULL;

    for (int i = 1; i < argc; i++) {
        if (strcmp(argv[i], "-u") == 0) {
            use_udp = 1;
        } else if (op_str == NULL) {
            op_str = argv[i];
        } else if (key == NULL) {
            key = argv[i];
        } else if (val == NULL) {
            val = argv[i];
        }
    }

    if (!op_str || !key || (strcmp(op_str, "SET") == 0 && !val)) {
        fprintf(stderr, "Usage: %s [-u] <host> <port> <SET|GET|DEL> <key> [value]\n"
                        "Or: %s [-u] <SET|GET|DEL> <key> [value] (defaults to localhost:5001)\n", argv[0], argv[0]);
        return 1;
    }

    /* Simple positional correction if host and port are supplied explicitly */
    if (argc >= 5 && strcmp(argv[argc-3], "SET") != 0 && ...) {
        host = argv[1];
        port = argv[2];
        op_str = argv[3];
        key = argv[4];
        if (argc == 6) val = argv[5];
    }

    uint32_t opcode = OP_GET;
    if (strcmp(op_str, "SET") == 0) opcode = OP_SET;
    else if (strcmp(op_str, "DEL") == 0) opcode = OP_DEL;

    char tx_buf[BUF_SIZE];
    memset(tx_buf, 0, sizeof(tx_buf));
    struct kv_request *req = (struct kv_request *)tx_buf;
    req->opcode = htonl(opcode);

    size_t key_len = strlen(key) + 1;
    memcpy(tx_buf + sizeof(struct kv_request), key, key_len);
    size_t payload_len = key_len;

    if (opcode == OP_SET && val) {
        size_t val_len = strlen(val) + 1;
        memcpy(tx_buf + sizeof(struct kv_request) + key_len, val, val_len);
        payload_len += val_len;
    }
    req->length = htonl(sizeof(struct kv_request) + payload_len);
    size_t total_tx_size = sizeof(struct kv_request) + payload_len;

    struct addrinfo hints, *result;
    memset(&hints, 0, sizeof(hints));
    hints.ai_family = AF_UNSPEC;
    hints.ai_socktype = use_udp ? SOCK_DGRAM : SOCK_STREAM;

    if (getaddrinfo(host, port, &hints, &result) != 0) {
        perror("getaddrinfo");
        return 1;
    }

    int fd = socket(result->ai_family, result->ai_socktype, result->ai_protocol);
    if (fd == -1) {
        perror("socket installation failed");
        freeaddrinfo(result);
        return 1;
    }

    if (!use_udp) {
        /* TCP Path execution */
        if (connect(fd, result->ai_addr, result->ai_addrlen) == -1) {
            perror("connect");
            close(fd);
            freeaddrinfo(result);
            return 1;
        }

        send(fd, tx_buf, total_tx_size, 0);

        struct kv_response res;
        recv(fd, &res, sizeof(struct kv_response), 0);
        uint32_t total_res_len = ntohl(res.length);
        uint32_t status = ntohl(res.status);

        if (status == STATUS_SUCCESS) {
            printf("SUCCESS: ");
            if (opcode == OP_GET && total_res_len > sizeof(struct kv_response)) {
                char rx_data[4096] = {0};
                recv(fd, rx_data, total_res_len - sizeof(struct kv_response), 0);
                printf("%s\n", rx_data);
            } else {
                printf("Operation Completed.\n");
            }
        } else if (status == STATUS_NOT_FOUND) {
            printf("NOT_FOUND\n");
        } else {
            printf("ERROR\n");
        }
    } else {
        /* UDP Path execution with Exponential Backoff Retries */
        int retry_count = 3;
        int current_timeout_ms = 200;
        int success = 0;

        char rx_buf[BUF_SIZE];

        for (int i = 0; i < retry_count; i++) {
            sendto(fd, tx_buf, total_tx_size, 0, result->ai_addr, result->ai_addrlen);

            struct timeval tv;
            tv.tv_sec = current_timeout_ms / 1000;
            tv.tv_usec = (current_timeout_ms % 1000) * 1000;
            setsockopt(fd, SOL_SOCKET, SO_RCVTIMEO, &tv, sizeof(tv));

            ssize_t n = recvfrom(fd, rx_buf, sizeof(rx_buf), 0, NULL, NULL);
            if (n >= (ssize_t)sizeof(struct kv_response)) {
                struct kv_response res;
                memcpy(&res, rx_buf, sizeof(struct kv_response));
                uint32_t total_res_len = ntohl(res.length);
                uint32_t status = ntohl(res.status);

                if (status == STATUS_SUCCESS) {
                    printf("SUCCESS: ");
                    if (opcode == OP_GET && total_res_len > sizeof(struct kv_response)) {
                        printf("%s\n", rx_buf + sizeof(struct kv_response));
                    } else {
                        printf("Operation Completed.\n");
                    }
                } else if (status == STATUS_NOT_FOUND) {
                    printf("NOT_FOUND\n");
                } else {
                    printf("ERROR\n");
                }
                success = 1;
                break;
            } else {
                printf("UDP Drop Detected. Backing off and retrying... (%d ms)\n", current_timeout_ms);
                current_timeout_ms *= 2; /* Double the timeout window */
            }
        }
        if (!success) {
            fprintf(stderr, "Transmission Failure: Server connection timed out after max retries.\n");
        }
    }

    close(fd);
    freeaddrinfo(result);
    return 0;
}
