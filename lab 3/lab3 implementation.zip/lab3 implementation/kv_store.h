#ifndef KV_STORE_H
#define KV_STORE_H

void store_init(void);
void store_set(const char *key, const char *value);
char *store_get(const char *key);
int store_del(const char *key);
void store_destroy(void);

#endif /* KV_STORE_H */