#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "kv_store.h"

#define BUCKET_COUNT 1024

struct kv_entry {
    char *key;
    char *value;
    struct kv_entry *next;
};

static struct kv_entry *table[BUCKET_COUNT];

static unsigned int hash(const char *str) {
    unsigned int h = 5381;
    int c;
    while ((c = (unsigned char)*str++)) {
        h = ((h << 5) + h) + c;
    }
    return h % BUCKET_COUNT;
}

void store_init(void) {
    memset(table, 0, sizeof(table));
}

void store_set(const char *key, const char *value) {
    unsigned int idx = hash(key);
    struct kv_entry *curr = table[idx];
    
    while (curr != NULL) {
        if (strcmp(curr->key, key) == 0) {
            free(curr->value);
            curr->value = strdup(value);
            return;
        }
        curr = curr->next;
    }
    
    struct kv_entry *entry = malloc(sizeof(struct kv_entry));
    entry->key = strdup(key);
    entry->value = strdup(value);
    entry->next = table[idx];
    table[idx] = entry;
}

char *store_get(const char *key) {
    unsigned int idx = hash(key);
    struct kv_entry *curr = table[idx];
    while (curr != NULL) {
        if (strcmp(curr->key, key) == 0) {
            return curr->value;
        }
        curr = curr->next;
    }
    return NULL;
}

int store_del(const char *key) {
    unsigned int idx = hash(key);
    struct kv_entry *curr = table[idx];
    struct kv_entry *prev = NULL;
    
    while (curr != NULL) {
        if (strcmp(curr->key, key) == 0) {
            if (prev == NULL) {
                table[idx] = curr->next;
            } else {
                prev->next = curr->next;
            }
            free(curr->key);
            free(curr->value);
            free(curr);
            return 0; /* Success */
        }
        prev = curr;
        curr = curr->next;
    }
    return -1; /* Not found */
}

void store_destroy(void) {
    for (int i = 0; i < BUCKET_COUNT; i++) {
        struct kv_entry *curr = table[i];
        while (curr != NULL) {
            struct kv_entry *tmp = curr;
            curr = curr->next;
            free(tmp->key);
            free(tmp->value);
            free(tmp);
        }
        table[i] = NULL;
    }
}