#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netdb.h>
#include <signal.h>
#include <netinet/in.h>

#include "kv_protocol.h"
#include "kv_store.h"

#define BUF_SIZE 65507

static volatile int keep_running = 1;

static void handle_signal(int sig) {
    (void)sig;
    keep_running = 0;
}

int main(int argc, char *argv[]) {
    char *port = "5001";
    int rcvbuf = 0, sndbuf = 0;

    for (int i = 1; i < argc; i++) {
        if (strcmp(argv[i], "--rcvbuf") == 0 && i + 1 < argc) {
            rcvbuf = atoi(argv[++i]);
        } else if (strcmp(argv[i], "--sndbuf") == 0 && i + 1 < argc) {
            sndbuf = atoi(argv[++i]);
        } else if (argv[i][0] != '-') {
            port = argv[i];
        }
    }

    struct sigaction sa;
    memset(&sa, 0, sizeof(sa));
    sa.sa_handler = handle_signal;
    sigaction(SIGINT, &sa, NULL);

    store_init();

    struct addrinfo hints, *result, *rp;
    memset(&hints, 0, sizeof(hints));
    hints.ai_family = AF_INET6; 
    hints.ai_socktype = SOCK_DGRAM;
    hints.ai_flags = AI_PASSIVE;

    if (getaddrinfo(NULL, port, &hints, &result) != 0) {
        perror("getaddrinfo");
        return 1;
    }

    int fd = -1;
    for (rp = result; rp != NULL; rp = rp->ai_next) {
        fd = socket(rp->ai_family, rp->ai_socktype, rp->ai_protocol);
        if (fd == -1) continue;

        int opt = 1;
        setsockopt(fd, SOL_SOCKET, SO_REUSEADDR, &opt, sizeof(opt));

        int v6only = 0;
        setsockopt(fd, IPPROTO_IPV6, IPV6_V6ONLY, &v6only, sizeof(v6only));

        if (rcvbuf > 0) setsockopt(fd, SOL_SOCKET, SO_RCVBUF, &rcvbuf, sizeof(rcvbuf));
        if (sndbuf > 0) setsockopt(fd, SOL_SOCKET, SO_SNDBUF, &sndbuf, sizeof(sndbuf));

        if (bind(fd, rp->ai_addr, rp->ai_addrlen) == 0) break;
        close(fd);
    }

    freeaddrinfo(result);

    if (!rp) {
        fprintf(stderr, "Could not bind UDP socket\n");
        return 1;
    }

    printf("UDP Server active on port %s (IPv4 + IPv6 Dual Stack Ready)...\n", port);

    char in_buf[BUF_SIZE];
    char out_buf[BUF_SIZE];

    while (keep_running) {
        struct sockaddr_storage cli_addr;
        socklen_t cli_len = sizeof(cli_addr);
        ssize_t n = recvfrom(fd, in_buf, sizeof(in_buf), 0, (struct sockaddr *)&cli_addr, &cli_len);
        if (n < (ssize_t)sizeof(struct kv_request)) continue;

        struct kv_request req;
        memcpy(&req, in_buf, sizeof(struct kv_request));
        uint32_t total_len = ntohl(req.length);
        uint32_t op = ntohl(req.opcode);

        if (n < (ssize_t)total_len) continue;

        char key[256] = {0};
        char val_buf[4096] = {0};
        size_t header_offset = sizeof(struct kv_request);

        if (total_len > header_offset) {
            size_t payload_len = total_len - header_offset;
            if (op == OP_SET) {
                /* Dynamically bound string extraction to prevent compiler warnings */
                size_t key_bytes = (payload_len < sizeof(key) - 1) ? payload_len : sizeof(key) - 1;
                memcpy(key, in_buf + header_offset, key_bytes);
                key[key_bytes] = '\0';
                
                size_t key_len = strlen(key) + 1;
                if (key_len < payload_len) {
                    size_t v_len = payload_len - key_len;
                    if (v_len > sizeof(val_buf) - 1) v_len = sizeof(val_buf) - 1;
                    memcpy(val_buf, in_buf + header_offset + key_len, v_len);
                }
            } else {
                size_t key_bytes = (payload_len < sizeof(key) - 1) ? payload_len : sizeof(key) - 1;
                memcpy(key, in_buf + header_offset, key_bytes);
                key[key_bytes] = '\0';
            }
        }

        memset(out_buf, 0, sizeof(out_buf));
        struct kv_response *res = (struct kv_response *)out_buf;
        size_t resp_payload_len = 0;

        if (op == OP_SET) {
            store_set(key, val_buf);
            res->status = htonl(STATUS_SUCCESS);
        } else if (op == OP_GET) {
            char *found = store_get(key);
            if (found) {
                res->status = htonl(STATUS_SUCCESS);
                resp_payload_len = strlen(found) + 1;
                memcpy(out_buf + sizeof(struct kv_response), found, resp_payload_len);
            } else {
                res->status = htonl(STATUS_NOT_FOUND);
            }
        } else if (op == OP_DEL) {
            if (store_del(key) == 0) {
                res->status = htonl(STATUS_SUCCESS);
            } else {
                res->status = htonl(STATUS_NOT_FOUND);
            }
        } else {
            res->status = htonl(STATUS_ERROR);
        }

        res->length = htonl(sizeof(struct kv_response) + resp_payload_len);
        sendto(fd, out_buf, sizeof(struct kv_response) + resp_payload_len, 0, (struct sockaddr *)&cli_addr, cli_len);
    }

    close(fd);
    store_destroy();
    return 0;
}