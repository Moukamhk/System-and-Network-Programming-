/*
 * http_common.h — Shared HTTP utilities for Lab 4
 *
 * Contains path sanitization, file serving, and request parsing
 * routines reused by all four server variants (basic, fork,
 * threadpool, epoll).
 */

#ifndef HTTP_COMMON_H
#define HTTP_COMMON_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <sys/sendfile.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <errno.h>

#define DOC_ROOT      "./wwwroot"
#define RECV_BUF_SIZE 8192
#define HDR_BUF_SIZE  512

/* ---------- path helpers ---------- */

/*
 * sanitize_path: checks that 'path' does not contain ".." (directory
 * traversal) and builds the filesystem path into 'out' (size 'outsz').
 * Returns 0 on success, -1 if the path is rejected.
 */
static inline int sanitize_path(const char *path, char *out, size_t outsz)
{
    /* Reject any traversal attempt */
    if (strstr(path, "..") != NULL)
        return -1;

    /* Default to index if root requested */
    if (strcmp(path, "/") == 0)
        path = "/small.html";

    snprintf(out, outsz, "%s%s", DOC_ROOT, path);
    return 0;
}

/* ---------- request parsing ---------- */

/*
 * parse_request: extracts the file path from the first line of an
 * HTTP/1.0 request stored in 'buf'.
 * Writes the path (e.g. "/foo.html") into 'path_out' (size 'sz').
 * Returns 0 on success, -1 on malformed request.
 */
static inline int parse_request(const char *buf, char *path_out, size_t sz)
{
    /* Expect: GET <path> HTTP/1.x */
    if (strncmp(buf, "GET ", 4) != 0)
        return -1;

    const char *start = buf + 4;
    const char *end   = strchr(start, ' ');
    if (!end)
        end = strchr(start, '\r');
    if (!end)
        end = strchr(start, '\n');
    if (!end)
        return -1;

    size_t len = (size_t)(end - start);
    if (len == 0 || len >= sz)
        return -1;

    memcpy(path_out, start, len);
    path_out[len] = '\0';
    return 0;
}

/* ---------- response helpers ---------- */

/*
 * send_404: writes a minimal HTTP/1.0 404 response to 'fd'.
 */
static inline void send_404(int fd)
{
    const char body[] = "<html><body><h1>404 Not Found</h1></body></html>";
    char hdr[HDR_BUF_SIZE];
    int hlen = snprintf(hdr, sizeof(hdr),
        "HTTP/1.0 404 Not Found\r\n"
        "Content-Length: %zu\r\n"
        "Content-Type: text/html\r\n"
        "\r\n",
        sizeof(body) - 1);

    send(fd, hdr,  (size_t)hlen,         MSG_NOSIGNAL);
    send(fd, body, sizeof(body) - 1,     MSG_NOSIGNAL);
}

/*
 * serve_file: opens 'fspath', sends HTTP/1.0 200 headers, then
 * streams the file via sendfile(). Returns 0 on success, -1 on error
 * (caller may then send a 404).
 */
static inline int serve_file(int client_fd, const char *fspath)
{
    struct stat st;
    if (stat(fspath, &st) < 0 || !S_ISREG(st.st_mode))
        return -1;

    int file_fd = open(fspath, O_RDONLY);
    if (file_fd < 0)
        return -1;

    /* Guess content-type from extension */
    const char *ctype = "application/octet-stream";
    const char *ext   = strrchr(fspath, '.');
    if (ext) {
        if (strcmp(ext, ".html") == 0 || strcmp(ext, ".htm") == 0)
            ctype = "text/html";
        else if (strcmp(ext, ".css") == 0)
            ctype = "text/css";
        else if (strcmp(ext, ".js") == 0)
            ctype = "application/javascript";
        else if (strcmp(ext, ".txt") == 0)
            ctype = "text/plain";
    }

    char hdr[HDR_BUF_SIZE];
    int hlen = snprintf(hdr, sizeof(hdr),
        "HTTP/1.0 200 OK\r\n"
        "Content-Length: %lld\r\n"
        "Content-Type: %s\r\n"
        "Connection: close\r\n"
        "\r\n",
        (long long)st.st_size, ctype);

    if (send(client_fd, hdr, (size_t)hlen, MSG_NOSIGNAL) < 0) {
        close(file_fd);
        return -1;
    }

    /* sendfile transfers data in-kernel, no user-space copy */
    off_t offset = 0;
    ssize_t remaining = st.st_size;
    while (remaining > 0) {
        ssize_t sent = sendfile(client_fd, file_fd, &offset, (size_t)remaining);
        if (sent <= 0) {
            if (errno == EINTR) continue;
            break;  /* client probably disconnected */
        }
        remaining -= sent;
    }

    close(file_fd);
    return 0;
}

/*
 * handle_client: full request/response cycle for one connected socket.
 * Shared by the basic, fork, and threadpool servers.
 */
static inline void handle_client(int client_fd)
{
    char   buf[RECV_BUF_SIZE];
    char   path[256];
    char   fspath[512];
    ssize_t n;

    /* Read the HTTP request (HTTP/1.0 — no persistent connections) */
    n = recv(client_fd, buf, sizeof(buf) - 1, 0);
    if (n <= 0) {
        close(client_fd);
        return;
    }
    buf[n] = '\0';

    if (parse_request(buf, path, sizeof(path)) < 0 ||
        sanitize_path(path, fspath, sizeof(fspath)) < 0) {
        send_404(client_fd);
        close(client_fd);
        return;
    }

    if (serve_file(client_fd, fspath) < 0)
        send_404(client_fd);

    close(client_fd);
}

/* ---------- listening socket setup ---------- */

/*
 * create_listen_socket: creates, binds, and listens on 'port'.
 * Sets SO_REUSEADDR. Returns the fd or exits on failure.
 */
static inline int create_listen_socket(int port)
{
    int fd = socket(AF_INET, SOCK_STREAM, 0);
    if (fd < 0) { perror("socket"); exit(EXIT_FAILURE); }

    int opt = 1;
    setsockopt(fd, SOL_SOCKET, SO_REUSEADDR, &opt, sizeof(opt));

    struct sockaddr_in addr = {
        .sin_family      = AF_INET,
        .sin_port        = htons((uint16_t)port),
        .sin_addr.s_addr = INADDR_ANY,
    };
    if (bind(fd, (struct sockaddr *)&addr, sizeof(addr)) < 0) {
        perror("bind"); exit(EXIT_FAILURE);
    }
    if (listen(fd, 128) < 0) {
        perror("listen"); exit(EXIT_FAILURE);
    }
    return fd;
}

#endif /* HTTP_COMMON_H */
