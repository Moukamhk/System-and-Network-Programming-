/*
 * http_fork.c — Task 2: Fork-per-Request HTTP/1.0 File Server
 *
 * Concurrency model: MULTI-PROCESS (one child process per connection).
 *
 * How it works:
 *   1. Parent calls accept() in a loop.
 *   2. For each accepted socket, the parent calls fork().
 *   3. The CHILD closes the listening socket, handles the request,
 *      and exits.
 *   4. The PARENT closes its copy of the client socket and loops back
 *      to accept() immediately — it never blocks on I/O.
 *
 * Trade-offs:
 *   + Strong isolation (a crash in one child cannot corrupt others).
 *   + Simple to reason about; no shared state.
 *   – High overhead: fork() copies page tables, file-descriptor tables,
 *     signal masks, etc. — expensive for short-lived requests.
 *   – Each child is a full process, so context-switch cost is high.
 *   – Under high load the process table can be exhausted.
 *
 * SIGCHLD handling:
 *   We use signal(SIGCHLD, SIG_IGN) which tells the kernel to reap
 *   children automatically (on Linux), preventing zombies without
 *   requiring a waitpid() loop.
 *
 * Usage:  ./http_fork [port]   (default 8080)
 */

#include "http_common.h"   /* shared socket/HTTP helpers */
#include <sys/wait.h>
#include <signal.h>

#define DEFAULT_PORT 8081

int main(int argc, char *argv[])
{
    int port = (argc > 1) ? atoi(argv[1]) : DEFAULT_PORT;

    /* ---- Step 1: Prevent zombie child processes ---- */
    /*
     * SIG_IGN for SIGCHLD: POSIX says ignored SIGCHLD causes the kernel
     * to reap children automatically without creating zombies.
     */
    signal(SIGCHLD, SIG_IGN);

    /* ---- Step 2: Create listening socket ---- */
    int listen_fd = create_listen_socket(port);
    printf("[fork] Listening on port %d (fork-per-request model)\n", port);

    /* ---- Step 3: Accept loop ---- */
    while (1) {
        struct sockaddr_in client_addr;
        socklen_t          addr_len = sizeof(client_addr);

        int client_fd = accept(listen_fd,
                               (struct sockaddr *)&client_addr,
                               &addr_len);
        if (client_fd < 0) {
            if (errno == EINTR) continue;
            perror("accept");
            continue;
        }

        /* ---- Step 4: Fork a child for this connection ---- */
        pid_t pid = fork();
        if (pid < 0) {
            perror("fork");
            close(client_fd);
            continue;
        }

        if (pid == 0) {
            /*
             * === CHILD PROCESS ===
             * The child inherited both file descriptors.
             * Close the listening socket — only the parent should accept.
             */
            close(listen_fd);

            /*
             * Serve this one request, then exit.
             * handle_client() closes client_fd when done.
             */
            handle_client(client_fd);
            exit(EXIT_SUCCESS);     /* child exits; kernel reaps it (SIG_IGN) */
        }

        /*
         * === PARENT PROCESS ===
         * The parent's copy of client_fd is no longer needed — the child
         * has its own duplicate. Close it to avoid leaking file descriptors.
         */
        close(client_fd);
        /* Parent loops immediately back to accept() */
    }

    close(listen_fd);
    return 0;
}
