/*
 * http_basic.c — Task 1: Baseline Blocking HTTP/1.0 File Server
 *
 * Concurrency model: NONE — one request at a time.
 * Purpose: correctness reference. Every request blocks the main loop
 * until it completes before the next accept() is called.
 *
 * Usage:  ./http_basic [port]   (default port 8080)
 * Test:   curl http://localhost:8080/small.html
 */

#include "http_common.h"   /* shared socket/HTTP helpers */

#define DEFAULT_PORT 8080

int main(int argc, char *argv[])
{
    int port = (argc > 1) ? atoi(argv[1]) : DEFAULT_PORT;

    /* ---- Step 1: create listening socket ---- */
    int listen_fd = create_listen_socket(port);
    printf("[basic] Listening on port %d (single-threaded, blocking)\n", port);

    /* ---- Step 2: accept loop ---- */
    while (1) {
        struct sockaddr_in client_addr;
        socklen_t          addr_len = sizeof(client_addr);

        int client_fd = accept(listen_fd,
                               (struct sockaddr *)&client_addr,
                               &addr_len);
        if (client_fd < 0) {
            if (errno == EINTR) continue;   /* interrupted by signal */
            perror("accept");
            continue;
        }

        /*
         * handle_client() reads the request, maps the path, sends
         * the file (or 404), then closes client_fd.
         * While this runs, no other connection can be accepted —
         * that is the defining limitation of this model.
         */
        handle_client(client_fd);
    }

    close(listen_fd);
    return 0;
}
