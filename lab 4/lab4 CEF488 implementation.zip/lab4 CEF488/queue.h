/*
 * queue.h — Thread-Safe Bounded Queue (Task 3 helper)
 *
 * Used by http_threadpool.c to pass accepted socket file-descriptors
 * from the main thread to worker threads.
 *
 * Design:
 *   - Fixed-capacity ring buffer (power-of-two size for simple masking).
 *   - Protected by a mutex + two condition variables (not_full, not_empty).
 *   - Sentinel value QUEUE_POISON (-1) lets the main thread signal
 *     workers to shut down cleanly.
 *
 * Why a separate header?
 *   The queue is a non-trivial data structure with its own state and
 *   locking logic. Separating it makes http_threadpool.c easier to read
 *   and allows the queue to be unit-tested independently.
 */

#ifndef QUEUE_H
#define QUEUE_H

#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define QUEUE_CAPACITY 1024   /* must be power of two */
#define QUEUE_POISON   (-1)   /* sentinel: tells worker threads to exit */

typedef struct {
    int             buf[QUEUE_CAPACITY];
    size_t          head;       /* next write position */
    size_t          tail;       /* next read position  */
    size_t          count;      /* number of items in queue */
    pthread_mutex_t lock;
    pthread_cond_t  not_empty;  /* signalled when an item is enqueued */
    pthread_cond_t  not_full;   /* signalled when an item is dequeued */
} queue_t;

/*
 * queue_init: initialises all fields. Call once before spawning threads.
 */
static inline void queue_init(queue_t *q)
{
    memset(q->buf, 0, sizeof(q->buf));
    q->head  = 0;
    q->tail  = 0;
    q->count = 0;
    pthread_mutex_init(&q->lock,      NULL);
    pthread_cond_init(&q->not_empty,  NULL);
    pthread_cond_init(&q->not_full,   NULL);
}

/*
 * queue_push: blocks until there is space, then enqueues 'fd'.
 * The main (producer) thread calls this after accept().
 */
static inline void queue_push(queue_t *q, int fd)
{
    pthread_mutex_lock(&q->lock);

    /* Wait while full */
    while (q->count == QUEUE_CAPACITY)
        pthread_cond_wait(&q->not_full, &q->lock);

    q->buf[q->head] = fd;
    q->head = (q->head + 1) & (QUEUE_CAPACITY - 1);
    q->count++;

    pthread_cond_signal(&q->not_empty);
    pthread_mutex_unlock(&q->lock);
}

/*
 * queue_pop: blocks until an item is available, then returns it.
 * Worker threads call this in their main loop.
 */
static inline int queue_pop(queue_t *q)
{
    pthread_mutex_lock(&q->lock);

    while (q->count == 0)
        pthread_cond_wait(&q->not_empty, &q->lock);

    int fd   = q->buf[q->tail];
    q->tail  = (q->tail + 1) & (QUEUE_CAPACITY - 1);
    q->count--;

    pthread_cond_signal(&q->not_full);
    pthread_mutex_unlock(&q->lock);
    return fd;
}

/*
 * queue_destroy: releases mutex/cond resources.
 */
static inline void queue_destroy(queue_t *q)
{
    pthread_mutex_destroy(&q->lock);
    pthread_cond_destroy(&q->not_empty);
    pthread_cond_destroy(&q->not_full);
}

#endif /* QUEUE_H */
