/*
 * http_threadpool.c — Task 3: Thread-Pool HTTP/1.0 File Server
 *
 * Concurrency model: MULTI-THREADED with a fixed-size worker pool.
 *
 * How it works:
 *   1. At startup, N worker threads are created (default = CPU cores).
 *   2. Each worker blocks on queue_pop(), waiting for a socket fd.
 *   3. The main thread calls accept() and queue_push()es the fd.
 *   4. A worker wakes up, handles the request, closes the socket.
 *
 * Trade-offs:
 *   + Much lower per-request overhead than fork (no process creation).
 *   + Threads share memory — easy to share caches/state if needed.
 *   – Shared state requires careful locking (the queue uses a mutex).
 *   – Number of threads is fixed; too few → queuing; too many → thrashing.
 *   – One misbehaving thread can corrupt the whole process.
 *
 * Dependencies: queue.h (thread-safe ring-buffer queue)
 *
 * Usage:  ./http_threadpool [port [num_threads]]   (default 8082, nproc)
 */

#include "http_common.h"   /* shared socket/HTTP helpers */
#include "queue.h"         /* thread-safe bounded queue */

#include <pthread.h>

#define DEFAULT_PORT    8082
#define DEFAULT_THREADS 4

/* Shared queue between main thread (producer) and workers (consumers) */
static queue_t g_queue;

/* ------------------------------------------------------------------ */
/* Worker thread entry point                                            */
/* ------------------------------------------------------------------ */

/*
 * worker_loop: each worker thread runs this function indefinitely.
 * It pops a socket fd from the queue, serves the request, then loops.
 * Receiving QUEUE_POISON (-1) is the shutdown signal.
 */
static void *worker_loop(void *arg)
{
    int thread_id = *(int *)arg;
    free(arg);

    printf("[threadpool] Worker %d started (tid=%lu)\n",
           thread_id, (unsigned long)pthread_self());

    while (1) {
        /* Block here until a connection is available */
        int client_fd = queue_pop(&g_queue);

        if (client_fd == QUEUE_POISON) {
            /*
             * Shutdown signal received. Re-push the poison pill so
             * that other workers also see it, then exit cleanly.
             */
            queue_push(&g_queue, QUEUE_POISON);
            break;
        }

        /*
         * handle_client() reads the HTTP request, maps the path,
         * serves the file (or 404), and closes client_fd.
         * This is the same routine used by the basic and fork servers.
         */
        handle_client(client_fd);
    }

    printf("[threadpool] Worker %d exiting\n", thread_id);
    return NULL;
}

/* ------------------------------------------------------------------ */
/* Main                                                                 */
/* ------------------------------------------------------------------ */

int main(int argc, char *argv[])
{
    int port       = (argc > 1) ? atoi(argv[1]) : DEFAULT_PORT;
    int num_threads= (argc > 2) ? atoi(argv[2]) : DEFAULT_THREADS;

    if (num_threads < 1 || num_threads > 256) {
        fprintf(stderr, "num_threads must be 1–256\n");
        return EXIT_FAILURE;
    }

    /* ---- Step 1: Initialise the shared queue ---- */
    queue_init(&g_queue);

    /* ---- Step 2: Spawn worker threads ---- */
    pthread_t *threads = malloc((size_t)num_threads * sizeof(pthread_t));
    if (!threads) { perror("malloc"); return EXIT_FAILURE; }

    for (int i = 0; i < num_threads; i++) {
        int *id = malloc(sizeof(int));   /* heap-allocated to avoid race */
        if (!id) { perror("malloc"); return EXIT_FAILURE; }
        *id = i;
        if (pthread_create(&threads[i], NULL, worker_loop, id) != 0) {
            perror("pthread_create");
            return EXIT_FAILURE;
        }
    }

    /* ---- Step 3: Create listening socket ---- */
    int listen_fd = create_listen_socket(port);
    printf("[threadpool] Listening on port %d with %d worker threads\n",
           port, num_threads);

    /* ---- Step 4: Accept loop — push fds into the queue ---- */
    while (1) {
        struct sockaddr_in client_addr;
        socklen_t          addr_len = sizeof(client_addr);

        int client_fd = accept(listen_fd,
                               (struct sockaddr *)&client_addr,
                               &addr_len);
        if (client_fd < 0) {
            if (errno == EINTR) continue;
            perror("accept");
            continue;
        }

        /*
         * Push the socket into the queue. A worker thread will wake
         * up and handle it. If the queue is full, this blocks until
         * a worker frees a slot.
         */
        queue_push(&g_queue, client_fd);
    }

    /*
     * Graceful shutdown (unreachable in this demo, but shows the pattern):
     * 1. Push one poison pill per worker.
     * 2. Join all workers.
     */
    for (int i = 0; i < num_threads; i++)
        queue_push(&g_queue, QUEUE_POISON);
    for (int i = 0; i < num_threads; i++)
        pthread_join(threads[i], NULL);

    queue_destroy(&g_queue);
    free(threads);
    close(listen_fd);
    return 0;
}
