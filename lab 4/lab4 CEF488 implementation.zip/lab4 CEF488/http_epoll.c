/*
 * http_epoll.c — Task 4: Event-Driven (epoll) HTTP/1.0 File Server
 *
 * Concurrency model: SINGLE-THREADED, event-driven using Linux epoll
 * in edge-triggered (EPOLLET) mode.
 *
 * How it works:
 *   1. The listening socket is added to an epoll instance.
 *   2. epoll_wait() sleeps until one or more sockets are ready.
 *   3. If the listening socket fires → accept all pending connections
 *      (loop until EAGAIN), set each non-blocking, add to epoll.
 *   4. If a client socket fires → read the full HTTP request,
 *      serve the response, close the socket.
 *
 * Edge-Triggered (EPOLLET) vs Level-Triggered (the default):
 *   Level-triggered: epoll_wait wakes up as long as data is available.
 *   Edge-triggered:  epoll_wait wakes up ONCE when new data arrives.
 *   → With ET we MUST read until EAGAIN or we miss remaining data.
 *   → ET reduces the number of epoll_wait wake-ups under high load.
 *
 * Trade-offs:
 *   + Single thread → zero lock contention, zero context switches.
 *   + Scales to thousands of idle connections cheaply (just fd + buffer).
 *   + Very low CPU overhead for I/O-bound workloads.
 *   – Long-running requests block the entire server (single thread).
 *   – More complex code: must handle partial reads/writes explicitly.
 *   – CPU-bound work should be offloaded to a thread pool.
 *
 * Usage:  ./http_epoll [port]   (default 8083)
 */

#include "http_common.h"   /* shared socket/HTTP helpers */

#include <sys/epoll.h>
#include <fcntl.h>

#define DEFAULT_PORT    8083
#define MAX_EVENTS      1024   /* max events returned per epoll_wait call */
#define CLIENT_BUF_SIZE 8192

/* ------------------------------------------------------------------ */
/* Helpers                                                             */
/* ------------------------------------------------------------------ */

/*
 * set_nonblocking: puts a file descriptor into non-blocking mode.
 * Required for edge-triggered epoll: a blocking read on an ET fd
 * would stall the entire server.
 */
static void set_nonblocking(int fd)
{
    int flags = fcntl(fd, F_GETFL, 0);
    if (flags < 0) { perror("fcntl F_GETFL"); return; }
    if (fcntl(fd, F_SETFL, flags | O_NONBLOCK) < 0)
        perror("fcntl F_SETFL");
}

/*
 * epoll_add: registers 'fd' on the epoll instance 'epfd' with events
 * EPOLLIN | EPOLLET (input, edge-triggered).
 */
static void epoll_add(int epfd, int fd)
{
    struct epoll_event ev;
    ev.events  = EPOLLIN | EPOLLET;
    ev.data.fd = fd;
    if (epoll_ctl(epfd, EPOLL_CTL_ADD, fd, &ev) < 0)
        perror("epoll_ctl ADD");
}

/*
 * handle_client_epoll: reads one HTTP/1.0 request from a non-blocking
 * socket, serves the response, then closes the socket.
 *
 * Because the socket is non-blocking and edge-triggered we loop recv()
 * until EAGAIN to ensure we read the complete request.
 */
static void handle_client_epoll(int client_fd)
{
    char   buf[CLIENT_BUF_SIZE];
    char   path[256];
    char   fspath[512];
    size_t total = 0;

    /*
     * Read until EAGAIN (no more data in the kernel buffer) or until
     * we see the end of the HTTP request header (\r\n\r\n or \n\n).
     * HTTP/1.0 requests are small so one recv() usually suffices.
     */
    while (total < sizeof(buf) - 1) {
        ssize_t n = recv(client_fd, buf + total,
                         sizeof(buf) - 1 - total, 0);
        if (n > 0) {
            total += (size_t)n;
            /* Check for end-of-headers marker */
            buf[total] = '\0';
            if (strstr(buf, "\r\n\r\n") || strstr(buf, "\n\n"))
                break;
        } else if (n == 0) {
            /* Client closed connection before sending a complete request */
            close(client_fd);
            return;
        } else {
            if (errno == EAGAIN || errno == EWOULDBLOCK)
                break;   /* no more data right now; process what we have */
            if (errno == EINTR)
                continue;
            perror("recv");
            close(client_fd);
            return;
        }
    }

    if (total == 0) {
        close(client_fd);
        return;
    }

    /* Parse and validate the HTTP request */
    if (parse_request(buf, path, sizeof(path)) < 0 ||
        sanitize_path(path, fspath, sizeof(fspath)) < 0) {
        send_404(client_fd);
        close(client_fd);
        return;
    }

    /*
     * For simplicity the response is sent synchronously (blocking send).
     * The response is small enough that the kernel buffer absorbs it
     * without blocking in practice. A production server would register
     * EPOLLOUT and handle partial writes asynchronously.
     */
    if (serve_file(client_fd, fspath) < 0)
        send_404(client_fd);

    /*
     * HTTP/1.0: close after each response. Remove the fd from epoll
     * implicitly (closing removes all registrations automatically).
     */
    close(client_fd);
}

/* ------------------------------------------------------------------ */
/* Main                                                                 */
/* ------------------------------------------------------------------ */

int main(int argc, char *argv[])
{
    int port = (argc > 1) ? atoi(argv[1]) : DEFAULT_PORT;

    /* ---- Step 1: Create listening socket and make it non-blocking ---- */
    int listen_fd = create_listen_socket(port);
    set_nonblocking(listen_fd);

    /* ---- Step 2: Create the epoll instance ---- */
    int epfd = epoll_create1(0);
    if (epfd < 0) { perror("epoll_create1"); return EXIT_FAILURE; }

    /* ---- Step 3: Register the listening socket with epoll ---- */
    epoll_add(epfd, listen_fd);
    printf("[epoll] Listening on port %d (single-threaded, edge-triggered epoll)\n", port);

    /* ---- Step 4: Event loop ---- */
    struct epoll_event events[MAX_EVENTS];

    while (1) {
        /*
         * epoll_wait blocks until at least one registered fd is ready.
         * Returns the number of ready events (stored in 'events[]').
         * Timeout -1 means wait forever.
         */
        int nready = epoll_wait(epfd, events, MAX_EVENTS, -1);
        if (nready < 0) {
            if (errno == EINTR) continue;
            perror("epoll_wait");
            break;
        }

        for (int i = 0; i < nready; i++) {
            int fd = events[i].data.fd;

            if (fd == listen_fd) {
                /*
                 * ---- New connection(s) arrived ----
                 * With EPOLLET we must accept() in a loop until EAGAIN
                 * to drain all pending connections from the backlog.
                 */
                while (1) {
                    struct sockaddr_in client_addr;
                    socklen_t          addr_len = sizeof(client_addr);

                    int client_fd = accept(listen_fd,
                                           (struct sockaddr *)&client_addr,
                                           &addr_len);
                    if (client_fd < 0) {
                        if (errno == EAGAIN || errno == EWOULDBLOCK)
                            break;   /* no more pending connections */
                        if (errno == EINTR)
                            continue;
                        perror("accept");
                        break;
                    }

                    /* Make client socket non-blocking and watch it */
                    set_nonblocking(client_fd);
                    epoll_add(epfd, client_fd);
                }

            } else {
                /*
                 * ---- Data available on a client socket ----
                 * Handle the request. The fd is closed inside, which
                 * automatically removes it from the epoll interest list.
                 */
                if (events[i].events & (EPOLLERR | EPOLLHUP)) {
                    /* Error or hang-up: just close the socket */
                    close(fd);
                    continue;
                }
                handle_client_epoll(fd);
            }
        }
    }

    close(epfd);
    close(listen_fd);
    return 0;
}
